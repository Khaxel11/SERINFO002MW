import { Injectable } from '@angular/core';
import { HttpClient, HttpParams,HttpHeaders} from '@angular/common/http';
import { UserJwt } from '../models/common/userJwt';
//import { environment } from 'src/environments/envir';
import { Observable } from 'rxjs';
import { environment } from '../../../src/environments/environment'

const URL_USUARIOERP = environment.SERTRAFAPI001;
@Injectable({
  providedIn: 'root'
})
export class DirectorioService {
    
  constructor(public http: HttpClient) { }

  
  getUsuarios(par: any): any {
    const url = URL_USUARIOERP + 'Directorio/getUsers';
      const params = new HttpParams()
        .append('NoEmpleado', par.nousuario)
        .append('Nombre', par.nombre)
        .append('Departamento', par.departamento)
        .append('Lugar', par.lugar)
        .append('Extension', par.extension)
        
    return this.http.get(url, { params });
  }
  getMarcado(par: string): any {
    const url = URL_USUARIOERP + 'Directorio/getMarcado';
      const params = new HttpParams()
        .append('Ubicacion', par)
        // .append('Nombre', par.nombre)
        // .append('Departamento', par.departamento)
        // .append('Lugar', par.lugar)
        // .append('Extension', par.extension)
        
    return this.http.get(url, { params });
  }
  getUbicacion(): any {
    const url = URL_USUARIOERP + 'Directorio/getUbicacion';
    return this.http.get(url);
  }
}
