export interface TipoProducto {
  idTipoProducto: string;
  tipoProducto: string;
}
export class TipoProducto {
  idTipoProducto: string;
  tipoProducto: string;
}
