export class TipoVariacion {
    idTipoVariacion: number;
    descripcion: string;
}