export class Provisiones{

  provision:boolean = false;
  idProvision:number;
  folioFactura:string;
  importeTotal:number;
  importeIva:number;
  fechaFactura:string;
  paridad:number;
  idMoneda:number;
}
