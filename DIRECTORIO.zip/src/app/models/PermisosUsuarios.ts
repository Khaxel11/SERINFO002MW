export class PermisosUsuarios{
  usuario: string;
  puesto: string;
  area: string;
}
