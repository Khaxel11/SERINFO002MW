export class Pais {
    clavePais: string;
    nombrePais: string;
    nomenclaturaPais: string;
}