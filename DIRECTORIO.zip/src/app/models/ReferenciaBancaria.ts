export class ReferenciaBancaria{
    idFormaPago: string
    nombreFormaPago: string
    Referencia: string
}