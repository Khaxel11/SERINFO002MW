export class Subcodigo {
  subcodigo: number;
  descripcion: string;
  codTipoIndustria: string;
}
