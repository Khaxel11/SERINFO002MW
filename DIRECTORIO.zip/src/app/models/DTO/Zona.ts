export class Zona{
    Zona: string;
    NombreZona: string;
    zona: string;
    nombreZona: string;
}
