export class OC_UnidadNegocio{
    OC: string;
    UnidadNegocio: string;
    EsActivo: boolean;
    Usuario: string;
}