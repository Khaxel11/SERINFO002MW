export class Relacion {
  articuloReferencia: string;
  piezasJuego: number;
  juego: boolean;
  esPricipal: boolean;
}
