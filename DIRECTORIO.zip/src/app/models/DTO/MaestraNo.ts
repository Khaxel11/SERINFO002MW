export class MaestraNo{
  maestraNo: string;
}
