export class EjecutivosAsignados {
    CodigoEjecutivo: number;
    Titular: boolean;
}