export class UsuarioERP{
    Id: string;
    Nombre: string;
    ZonaId: string;
    Correo: string;
    DepartamentoId: number;
}