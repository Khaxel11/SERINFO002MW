export class TipoPapel {
  idTipoPapel: number;
  clavePapel: string;
}
