export class Ejecutivos{
    CodigoEjecutivo: number;
    IdUsuario: string;
    Zona: string;
    NumeroTelefono: string;
    Nombre: string;
    Estatus: boolean;
}