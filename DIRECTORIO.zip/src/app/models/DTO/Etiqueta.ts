export class Etiqueta {
  label: number;
  precioUnitario: number;
  escalaEtiqueta: number;
  largo: number;
  ancho: number;
}
