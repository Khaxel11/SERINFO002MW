export class UsosCFDI {
    idUsoCfdi : string
    descripcionCFDI : string
    fisica : string
    moral : string
    fechaInicioDeVigencia : Date
    fechaFinDeVigencia : Date
}