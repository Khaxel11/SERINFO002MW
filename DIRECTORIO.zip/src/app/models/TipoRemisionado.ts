export class TipoRemisionado{
    idTipoRemisionado: number
    tipoRemisionado: string
}