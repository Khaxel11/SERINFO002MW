export class Variacion {
    idVariacion: number;
    descripcion: string;
}