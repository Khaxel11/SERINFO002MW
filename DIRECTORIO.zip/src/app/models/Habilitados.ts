export interface Habilitado {
    idCliente:string;
    razonSocial: string;
    idHabilitado:string;
    idClienteRel:string;
}
export class Habilitado {
    idCliente:string;
    razonSocial: string;
    idHabilitado:string;
    idClienteRel:string;
}