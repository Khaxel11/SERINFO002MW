export class UnidadMedida {
    idUnidadMedida: number;
    unidadMedida: string;
}
export interface UnidadMedida {
    idUnidadMedida: number;
    unidadMedida: string;
}
