export interface Flauta {
  flauta: string;
  corrugado: string;
  descripcion: string;
}
export class Flauta {
    flauta: string;
    corrugado: string;
    descripcion: string;
}
