export interface iProveedor{
    id:number,
    name: string
}