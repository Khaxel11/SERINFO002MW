export interface IDatosIva{
    idIva: number
    valorIva: number
}