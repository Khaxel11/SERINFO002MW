export interface IClaveDescripcion{
    id:number,
    descripcion:string
}