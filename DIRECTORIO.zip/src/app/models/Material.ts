export class Material {
  idMaterial: number;
  material: string;
  idUnidad: number;
  unidad: string;
  costo: number;
}
export interface Material {
    idMaterial: number;
    material: string;
    idUnidad: number;
    unidad: string;
    costo: number;
  }
