export class Estado{
    claveEstado: string;
    nombreEstado: string;
    clavePais: string;
    claveSAT: string;
}