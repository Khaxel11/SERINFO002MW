export class Correos{
    IdUsaurio: string;
    Correo: string;
    Nombre: string;
    NotFactura: boolean;
    NotPacList: boolean;
    NotRemision: boolean;
    Telefono: string;
}

export class Contacto {
    idContacto = 0;
    correo = '';
    nombre = '';
    notFactura = false;
    notPacList = false;
    notRemision = false;
    telefono = '';
    idCliente ? = '';
}

export class ContactoFiltros {
    idCliente = '';
}
