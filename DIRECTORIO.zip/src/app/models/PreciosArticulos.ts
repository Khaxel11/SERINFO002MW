export class PreciosArticulos {
  ClaveArticulo:string;
  PrecioVenta:number;
  Volumen1:number;
	Precio1:number;
	Volumen2:number;
	Precio2:number;
	Volumen3:number;
	Precio3:number;
	VentaXVolumen:boolean;
	Dollar:boolean;
	PrecioDollar:boolean;
}
