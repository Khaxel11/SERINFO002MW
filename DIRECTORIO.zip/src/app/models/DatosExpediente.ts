export interface DatosExpediete {
    idCliente: string;
    tipoDocumento: string;
    descripcion: string;
    idDocumento: number;
    nombreArchivo: string;
    fecha: string;
}
export class DatosExpediete {
    idCliente: string;
    tipoDocumento: string;
    descripcion: string;
    idDocumento: number;
    nombreArchivo: string;
    fecha: string;
}
