export interface Paso1 {
  idCliente: string;
  idLugarEntrega: number;
  descripcion: string;
  idDocumento: number;
  nombreArchivo: string;
  fechaRecordatorio: string;
  fechaVencimiento: string;
  usuarioInsert: string;
}
export class Paso1 {
  idCliente: string;
  idLugarEntrega: number;
  descripcion: string;
  idDocumento: number;
  nombreArchivo: string;
  fechaRecordatorio: string;
  fechaVencimiento: string;
  usuarioInsert: string;
}
