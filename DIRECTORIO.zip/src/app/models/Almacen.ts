export class Almacen {
    cod: string
    nombre: string
    ubicacion: string
}