export type AccionModal = 'Agregar' | 'Editar' | 'Eliminar' | 'Mostrar';
export enum AccionesModal {
    Agregar = 'Agregar',
    Editar = 'Editar',
    Eliminar = 'Eliminar',
    Mostrar = 'Mostrar'
}
