export interface ModalModel {
    openModal: () => void;
    closeModal: () => void;
}
