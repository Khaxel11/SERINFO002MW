export class ReglasCondiciones {
    IdRegla: number;
    NombreRegla: string;
    UsuarioResponsable: string;
    IdCondicion: number;
    NombreCondicion: string;
    DescripcionCondicion: string;
    DescripcionSoluciones: string;
    MensajeInformativo: string;
    ReferenciaCondicion: string;
    ReferenciaDescripcionCondicion: string;
    Nomenclatura: string;
    IdTipoMensaje: number;
    estatusCondicion: boolean;
}
