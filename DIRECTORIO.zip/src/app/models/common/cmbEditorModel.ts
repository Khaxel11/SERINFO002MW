export interface CmbOption {
    value?: any;
    text?: string;
}
