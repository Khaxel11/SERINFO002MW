export interface GridParams {
    startRow: number;
    endRow: number;
}
