export class UserJwt {
  IdUsuario: string;
  Zona: string;
}
