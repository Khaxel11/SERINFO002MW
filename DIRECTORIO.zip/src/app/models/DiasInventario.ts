export class DiasInventario {
    clave: number
    diasMaxInventario: string
}