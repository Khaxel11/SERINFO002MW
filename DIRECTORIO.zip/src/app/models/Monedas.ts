export class Monedas {
    moneda : string
    nombre : string
    tCCompra : number
    tCVenta : number
    nombreCorto : string
    utilFacturacion : boolean
    numeroCuenta : string
    claveSAT : string
}