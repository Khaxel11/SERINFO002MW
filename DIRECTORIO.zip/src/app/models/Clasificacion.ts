export interface Clasificacion {
  idClasificacion: number;
  clasificacion: string;
  mostrarPorDefault: boolean;
}
export class Clasificacion {
  idClasificacion: number;
  clasificacion: string;
  mostrarPorDefault: boolean;
}
