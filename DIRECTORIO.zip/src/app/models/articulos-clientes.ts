export class FiltroArticulosClientes {
    claveCliente = '';
    claveAgente = '';
    claveArticulo = '';
    numDesarrollo = '';
    descripcion = '';
}
