export class Credito {
    claveCondicion: string;
    tipo: string
    Dias: number;
}