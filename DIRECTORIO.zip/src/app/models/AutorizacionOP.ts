export class AutorizacionOP {
  folioModOP: number;
  op: number;
  serie: string;
  ordenImpres: number;
  fecha: Date;
  tipoModificacion: string;
  autPreliminarCartera: boolean;
  autPreliminarCostos: boolean;
  autVentas: boolean;
  fechaAutCartera: string;
  fechaAutCostos: string;
  fechaAutVentas: string;
  usuario: string;
  strOP: string;
}
