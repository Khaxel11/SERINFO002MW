import { Component, OnInit,ViewChild } from '@angular/core';
import swal from 'sweetalert2';
import { CuentasxPagarService } from '../../../../services/cuentasXpagar.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { FacturasProveedoresService } from 'src/app/services/CuentasXPagar/FacturasProveedores.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-admcxpa004-mw',
  templateUrl: './admcxpa004-mw.component.html',
  styleUrls: ['./admcxpa004-mw.component.css']
})
export class ADMCXPA004MWComponent implements OnInit {
usuarios = [];
diasCredito = []
columnDefs: any;
filas = new Array<any>();
moneda = []
activar:any;
@ViewChild('mdlBuscar') public mdlBuscar: any;
@ViewChild('mdlFactura') public mdlFactura: any;
@ViewChild('gridCuentas') public gridCuentas: any;
  modalRef: NgbModalRef;
  public filtrosBusqueda = {
    fechaInicio:this.initialDate(),
    fechaFin:this.initialDate(),
    idProveedor:"",
    folio:"",
    usuario:"",
    startRow:0,
    endRow:0
  };
  objCuenta ={
    folio :"",
    adicional1:"",
    adicional2:"",
    adicional3:"",
    adicional4:"",
    fechaAdicional2:this.initialDate(),
    fechaAdicional3:this.initialDate(),
    fechaAdicional4:this.initialDate(),
    idProveedor:"",
    nombreProveedor:"",
    idFactura:0,
    uuid:"",
    idMoneda:0,
    paridad:0,
    importeTotal:0
  }
  constructor(public cuentasPagar:CuentasxPagarService,public modalService: NgbModal,public router: Router, public facturasProveedor:FacturasProveedoresService) {
    this.columnDefs = [
      {
        headerName: 'FolioCxp',
        field: 'folio',
        flex: 8,
        minWidth: 80,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Proveedor',
        field: 'nombreProveedor',
        flex: 10,
        minWidth: 100,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Adicional',
        field: 'adicional1',
        flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Total',
        field: 'importeTotal',
        flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Editar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.loadModal.bind(this),
          label: '<i class="fa fa-edit"></i>',
          class: 'btn btn-warning btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
      {
        headerName: 'Eliminar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.GridEliminar.bind(this),
          label: '<i class="fa fa-trash"></i>',
          class: 'btn btn-danger btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      }
    ];
   }

  ngOnInit(): void {
    this.listarUsuarios();

  }

  listarUsuarios() {
    this.cuentasPagar.getUsuarios().subscribe(
      (data: any) => {
        if(data.data.length > 0){

        this.usuarios = data.data;

        }else{
          this.usuarios = [];
        }
        this.LoadDataTiposMoneda();
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar las facturas, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }




  openModal(){
    this.modalRef = this.modalService.open(this.mdlBuscar, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    this.modalRef.result.then(() => {

    });
  }
loadModal(e){
  console.log(e.data);
  this.objCuenta.idProveedor = e.data.idProveedor;
  this.objCuenta.folio = e.data.folio;
  this.objCuenta.adicional1 = e.data.adicional1;
  this.objCuenta.nombreProveedor = e.data.nombreProveedor;
  this.objCuenta.idFactura = e.data.idFactura;
  this.objCuenta.uuid = e.data.uuid;
  this.objCuenta.paridad = e.data.paridad;
  if(this.objCuenta.idMoneda == 0){
    this.objCuenta.paridad = 1;
  }else{
    this.objCuenta.paridad = e.data.paridad;
  }
  this.objCuenta.idMoneda = e.data.idMoneda;
  this.objCuenta.adicional2 = e.data.adicional2;
  this.objCuenta.adicional3 = e.data.adicional3;
  this.objCuenta.adicional4 = e.data.adicional4;
  this.openModal();
}


  //CERRAR MODAL
  closeModal(): void {
    this.modalRef.close();
    this.activar = false;
  }
  goToAddView(){
    this.router.navigate(['admcxpa004mw/admcxpa004mw', 'add']);
  }

  GridEliminar(e): void {
    swal
      .fire({
        title: '¿Está seguro de eliminar la CxP?',
        text: '',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
      })
      .then((result) => {
        if (result.isConfirmed) {
          this.cuentasPagar.eliminarCxp(String(e.data.folio)).subscribe(
            (data: any) => {
              if (data.data.errorMessage != "") {
                if(data.data.mensaje.length<=0){
                  swal.fire(
                    '',
                    'Los cambios en el registro fueron exitosos',
                    'success'
                  );
                  this.gridCuentas.refreshData();
                }else{
                  swal.fire('',data.data.mensaje,'warning');
                }
              } else {
                swal.fire(
                  '',
                  'Ocurrió un error al tratar de hacer los cambios. ' +
                    data.mensaje,
                  'error'
                );
              }
            },
            (error) => {
              swal.fire(
                'Datos ',
                'Ha Ocurrio un Error al Momento de Eliminar o Activar la Cuenta x Pagar,' +
                  ' Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas,' +
                  ' <strong>Código de Error: ' +
                  error.error +
                  '</strong>',
                'error'
              );
            }
          );
        }
        //this.gridProvisiones.refreshData();
      });
  }

  listarCxp(){
    this.gridCuentas.refreshData();
  }

  abrirModalFacturas(){
    this.filas = [];
    this.filas.push(this.objCuenta);
    this.mdlFactura.filas = this.filas;
    this.mdlFactura.openModal();

  }
  // cargar combo tipo de moneda
  LoadDataTiposMoneda() {
    this.facturasProveedor.GetListadoMonedas().subscribe(
      (data: any) => {
        this.moneda = data.data;
      },
      (error) => {
        swal.fire(
          'Error',
          'Ha Ocurrio un Error al Momento de Cargar Tipos de Moneda, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }

  cambiarMoneda(e){
if(e.target.checked){
  this.activar= true;
}else{
  this.activar = false;
}
  }

  setDatosFactura(data){
    console.log(data)
    this.objCuenta.idFactura = data.idFactura;
    this.objCuenta.uuid = data.uuid;
    this.objCuenta.adicional1 = data.folioFactura;
    this.objCuenta.importeTotal = data.importeTotal;
    if(data.idMoneda != this.objCuenta.idMoneda){
      swal.fire('', 'El tipo de moneda seleccionado no coincide con el de la factura','warning');
    }else{
      this.objCuenta.idMoneda = data.idMoneda;
    }
    //this.objCuenta.fechaAdicional1 = this.datepipe.transform(data.fechaCarga,'yyyy-MM-dd');
  }
  public fadicional1:any;
    fechaAdicional1(event:KeyboardEvent){
      console.log(event)
      if(event.key != "" && event.key != null && event.key != " " && event.key !="Backspace" && event.key != "ArrowDown" && event.key != "ArrowUp" && event.key != "ArrowLeft" && event.key != "ArrowRight"){
        this.fadicional1 = true;

      }else{
        this.fadicional1 = false;
      }

    }

    public fadicional2:any;
    fechaAdicional2(event){

      if(event.key != "" && event.key != null && event.key != " " && event.key !="Backspace" && event.key != "ArrowDown" && event.key != "ArrowUp" && event.key != "ArrowLeft" && event.key != "ArrowRight"){
        this.fadicional2 = true;

      }else{
        this.fadicional2 = false;
      }
    }
    public fadicional3:any;
    fechaAdicional3(event){

      if(event.key != "" && event.key != null && event.key != " " && event.key !="Backspace" && event.key != "ArrowDown" && event.key != "ArrowUp" && event.key != "ArrowLeft" && event.key != "ArrowRight"){
        this.fadicional3 = true;

      }else{
        this.fadicional3 = false;
      }

    }


    initialDate(): string {
      let date = new Date();
      let day = date.getDate().toString();
      let month = (1 + date.getMonth()).toString();
      let year = date.getFullYear().toString();

      day.length == 1 ? day = "0" + day : null;

      month.length == 1 ? month = "0" + month : null;

      return year + "-" + month + "-" + day;
    }

    editarCxp(){
      this.cuentasPagar.editarCxp(this.objCuenta).subscribe((data: any) => {
      if (data.data.errorMessage == null) {
        if(data.data.mensaje == null){
        swal.fire(
          '',
          'Datos guardados correctamente',
          'success'
        );

          this.closeModal();
        this.objCuenta = {
          folio:"",
          idProveedor:"",
          nombreProveedor:"",
          idMoneda:0,
          paridad:0,
          adicional1:"",
          adicional2:"",
          fechaAdicional2:"",
          adicional3:"",
          fechaAdicional3:"",
          adicional4:"",
          fechaAdicional4:"",
          idFactura:0,
          uuid:"",
          importeTotal:0
        };
        this.activar = false;
        this.gridCuentas.refreshData();
      }else{
        swal.fire('',data.data.mensaje,'warning');
          }
      } else {
        swal.fire(
          '',
          'Ocurrió un error al tratar de guardar los datos ' +
            data.data.errorMessage,
          'error'
        );
      }
    },
    (error) => {
      swal.fire(
        'Datos ',
        ' Ocurrió un Error al Momento de Editar la cuenta por pagar' +
          ' Favor de Comunicarse con el Área de Informática y Generar un Reporte de Fallas,' +
          ' <strong>Código de Error: ' +
          error.error +
          '</strong>',
        'error'
      );
    }
    );
  }

  public monedaValor :any;
  public fechaActual = this.initialDate();
    obtenerTipoCambio(){
      for (const iterator of this.moneda) {
        if (this.objCuenta.idMoneda === iterator.idMoneda) {
          this.monedaValor = iterator.descripcionMoneda;
        }
      }
      this.cuentasPagar.obtenerTipoCambio(this.fechaActual).subscribe((success:any) =>{
        if(this.objCuenta.idMoneda == 0){
          this.objCuenta.paridad = 1;
        }
        if(success.data.length > 0){
          if(this.objCuenta.idMoneda == 1){
            console.log(success.data)
            this.objCuenta.paridad = success.data[0].paridad;
            if(this.objCuenta.paridad == null){
              swal.fire('','No se encontró tipo de cambio para esta fecha','warning');
              this.objCuenta.paridad = 0;
            }
          }
        }
      }, Error => {
        swal.fire('Error!', 'Error al llamar servicios ' + Error, 'error');

      });
    }
}
