import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ADMCXPA004MWComponent } from './admcxpa004-mw.component';

describe('ADMCXPA004MWComponent', () => {
  let component: ADMCXPA004MWComponent;
  let fixture: ComponentFixture<ADMCXPA004MWComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ADMCXPA004MWComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ADMCXPA004MWComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
