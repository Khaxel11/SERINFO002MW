import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ADMCXPA004MWAddComponent } from './admcxpa004-mwadd.component';

describe('ADMCXPA004MWAddComponent', () => {
  let component: ADMCXPA004MWAddComponent;
  let fixture: ComponentFixture<ADMCXPA004MWAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ADMCXPA004MWAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ADMCXPA004MWAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
