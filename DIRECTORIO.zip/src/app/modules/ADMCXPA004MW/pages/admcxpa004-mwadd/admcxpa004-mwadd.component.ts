import { Component, OnInit,ViewChild } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { CuentasxPagarService } from 'src/app/services/cuentasXpagar.service';
import { FacturasProveedoresService } from 'src/app/services/CuentasXPagar/FacturasProveedores.service';
import { FacturasProveedorService } from 'src/app/services/facturasProveedor';
import swal from 'sweetalert2';
import { DatePipe, DecimalPipe } from '@angular/common';
import { Router } from '@angular/router';
import { Provisiones } from '../../../../models/Provisiones'
import { GridModel } from 'src/app/models/common/gridModel';
import { cloneDeep } from 'lodash-es';

@Component({
  selector: 'app-admcxpa004-mwadd',
  templateUrl: './admcxpa004-mwadd.component.html',
  styleUrls: ['./admcxpa004-mwadd.component.css']
})
export class ADMCXPA004MWAddComponent implements OnInit {
  @ViewChild('mdlProveedor') public mdlProveedor: any;
  @ViewChild('mdlFactura') public mdlFactura: any;
  @ViewChild('mdlAdicionales') public mdlAdicionales: any;
  @ViewChild('mdlRepetitivo') public mdlRepetitivo: any;
  @ViewChild('mdlEntradas') public mdlEntradas: any;
  @ViewChild('gridProvisiones') public gridProvisiones: GridModel;
  filas = new Array<any>();
  actionMode= 'add';
  titulo ='Captura de cuentas por pagar';
  tiposcxp = [];
  movimiento = [];
  moneda = [];
  modalRef: NgbModalRef;
  modalReference: NgbModalRef;
  public filtrosEntradas = {
    idProveedor:"",
    de:"",
    hasta:"",
    startRow:0,
    endRow:9999,
    folio:""
  };
  public objAdicional = {
    adicional1:"",
    fechaAdicional1:"",
    adicional2:"",
    fechaAdicional2:this.initialDate(),
    adicional3:"",
    fechaAdicional3:this.initialDate(),
    adicional4:"",
    fechaAdicional4:this.initialDate(),
    idFactura:0,
    uuid:"",
    idMoneda:0,
    idIva:0,
    importeIva:0.0000,
    tasaIsr:0,
    importeIsr:0.0000,
    tasaIsrIva:0,
    importeIsrIva:0.0000,
    importeTotal:0.0000,
    importeSubtotal:0.0000,
  }
  public objCuenta = {
    folio:"",
    id:0,
    idTipoCxp:0 as number,
    idTipoMovto:"",
    folioProveedor:"",
    idProveedor:"",
    nombreProveedor:"",
    fecha:"",
    documento:"",
    idDiasCredito:0,
    idMoneda:0,
    importeSubtotal:0.0000,
    paridad:0.0000,
    idIva:0,
    importeIva:0.0000,
    tasaIsr:0,
    importeIsr:0.0000,
    tasaIsrIva:0,
    importeIsrIva:0.0000,
    otrosImportes:0.0000,
    otrosExentos:0.0000,
    otrasRetenciones:0.0000,
    importeTotal:0.0000,
    cargo:0,
    abono:0,
    saldo:0,
    adicional:"",
    adicional1:"",
    idFactura:0,
    uuid:"",
    fechaAdicional1:"",
    adicional2:"",
    fechaAdicional2:"",
    adicional3:"",
    fechaAdicional3:"",
    adicional4:"",
    fechaAdicional4:"",
    flete:false,
    idRepetitivo:0,
    nombreRepetitivo:"",
    idProvision:0
  };
  public objEntradas = {
    folio:"",
    id:0,
    idTipoCxp:0 as number,
    idTipoMovto:"",
    folioProveedor:"",
    idProveedor:null as number,
    nombreProveedor:"",
    fecha:"",
    documento:"",
    idDiasCredito:0,
    idMoneda:0,
    importeSubtotal:0.0000,
    paridad:0.0000,
    idIva:0,
    importeIva:0.0000,
    tasaIsr:0,
    importeIsr:0.0000,
    tasaIsrIva:0,
    importeIsrIva:0.0000,
    otrosImportes:0.0000,
    otrosExentos:0.0000,
    otrasRetenciones:0.0000,
    importeTotal:0.0000,
    cargo:0,
    abono:0,
    saldo:0,
    adicional:"",
    adicional1:"",
    idFactura:0,
    uuid:"",
    fechaAdicional1:"",
    adicional2:"",
    fechaAdicional2:"",
    adicional3:"",
    fechaAdicional3:"",
    adicional4:"",
    fechaAdicional4:"",
    flete:false,
    idRepetitivo:0,
    nombreRepetitivo:""
  };
  diasCredito = [];
  iva = []
  public filtrosOc = {
    folio:"",
    idProveedor:""
  };
  columnDefs:any;
  columns:any;
  columnsProvision:any;
  datos= []
  entradas = []
  provisiones:Provisiones[];
  filtrosProvisiones = {
    idProveedor:"",
    startRow:0,
    endRow:9999
  };
  constructor(public cuentasPagar:CuentasxPagarService, public factura: FacturasProveedorService, public facturasProveedor:FacturasProveedoresService,public modalService: NgbModal,public datepipe: DatePipe,public router: Router) {
    this.columnDefs = [
      {
        headerName: 'Id',
        field: 'idRepetitivo',
        flex: 2,
        minWidth: 80,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Repetitivo',
        field: 'nombreRepetitivo',
        flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'MasInformación',
        field: 'masInformacion'
        ,flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Seleccionar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.seleccionar.bind(this),
          label:
            '<i class="fa fa-check"></i>',
          class: 'btn btn-success btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
    ];

    this.columns = [
      {
        headerName: 'Folio',
        field: 'folioEntrada',
        flex: 3,
        minWidth: 200,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Importe',
        field: 'importeTotal',
        flex: 2,
        minWidth: 200,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },

      {
        headerName: 'Fecha',
        field: 'fechaEntrada',
        flex: 2,
        minWidth: 150,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      }
      ,
      {
        headerName: 'Seleccionar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.seleccionarEntrada.bind(this),
          label:
            '<i class="fa fa-check"></i>',
          class: 'btn btn-success btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 1,
        minWidth: 90,
        suppressSizeToFit: true,
      }
    ];

    this.columnsProvision = [
      {
        headerName: ' ',
        field: 'provision',
        flex: 1,
        minWidth: 40,
        maxWidth:50,
        headerClass: 'header-center header-grid',
        cellRenderer: 'hybCellRenderer',
        cellClass: 'grid-cell-btn-center',
        cellRendererParams: {
          type: 'chk',
          disabled: false,
          change: this.seleccionarProvisiones.bind(this)
        }
      },
      {
        headerName: 'Factura',
        field: 'folioFactura',
        flex: 3,
        minWidth: 200,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Importe',
        field: 'importeTotal',
        flex: 2,
        minWidth: 200,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'IVA',
        field: 'importeIva',
        flex: 2,
        minWidth: 100,
        maxWidth:120,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Fecha Factura',
        field: 'fechaFactura',
        flex: 2,
        minWidth: 150,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Tipo Cambio',
        field: 'paridad',
        flex: 2,
        minWidth: 150,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Moneda',
        field: 'idMoneda',
        flex: 2,
        minWidth: 150,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      }
    ];
  }

  ngOnInit(): void {
    this.listarTiposCxp();
    this.objCuenta.fecha = this.initialDate();

    if(this.objCuenta.idMoneda == 0){
      this.objCuenta.paridad = 1;
    }

  }

  listarTiposCxp() {
    this.cuentasPagar.getTiposCxp().subscribe(
      (data: any) => {
        if(data.data.length > 0){
        this.tiposcxp = data.data;
        this.CargarTipoMovimientos();
        }else{
          this.tiposcxp = [];
        }
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar las facturas, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }

  CargarTipoMovimientos() {
    this.factura.getTipoMovimientos().subscribe(
      (data: any) => {
        this.movimiento = data.data;
        this.LoadDataTiposMoneda()
      },
      (error) => {
        swal.fire(
          'Error',
          'Ha Ocurrio un Error al Momento de Cargar Tipo de Movimientos, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }

   // cargar combo tipo de moneda
   LoadDataTiposMoneda() {
    this.facturasProveedor.GetListadoMonedas().subscribe(
      (data: any) => {
        this.moneda = data.data;
        this.CargarIvas();
        this.getDiasCredito();
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar Tipos de Moneda, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }
  public nacionalidad:any;
  SetProveedorSelected(e){
    this.objCuenta.idProveedor = e.id;
    this.objCuenta.folioProveedor = e.codigo;
    this.objCuenta.nombreProveedor = e.descripcion;
    this.nacionalidad = e.nacionalidad;
    if(e.idDiasCredito == null || e.idDiasCredito == ""){
      this.objCuenta.idDiasCredito = 0;
    }else{
      this.objCuenta.idDiasCredito = e.idDiasCredito;
    }
    this.listarProvisiones();
  }

  open(){
    this.mdlProveedor.openModal();
  }

  openModal(){
    console.log(this.objCuenta.idProveedor)
    if(this.objCuenta.idProveedor != ""){
      this.modalRef = this.modalService.open(this.mdlAdicionales, {
        size: 'lg',
        backdrop: 'static',
        keyboard: false
      });
      for (const iterator of this.tiposcxp) {
        if (this.objCuenta.idTipoCxp === iterator.idTipoCxp) {
          this.objAdicional.adicional3 = iterator.descripcion;
        }
      }
      this.modalRef.result.then(() => {

      });
    }else{
      swal.fire('','Debe capturar un proveedor primero','warning');
    }

  }

  openModalEntradas(){
    this.objCuenta.documento = "";
    this.filtrosEntradas.de = this.fechaXvDias();
    this.filtrosEntradas.hasta = this.initialDate();
    this.filtrosEntradas.folio = "";
    this.objCuenta.idProveedor = "";
    this.entradas = []
      this.modalReference = this.modalService.open(this.mdlEntradas, {
        size: 'lg',
        backdrop: 'static',
        keyboard: false
      });

      this.modalReference.result.then(() => {
      });


  }
  openMFactura(){
    this.filas = [];
    this.filas.push(this.objCuenta);
    this.mdlFactura.filas = this.filas;
    this.mdlFactura.openModal();
  }

  //CERRAR MODAL
  closeModal(): void {
    this.modalRef.close();
    this.objAdicional = {
      adicional1:"",
      fechaAdicional1:"",
      adicional2:"",
      fechaAdicional2:this.initialDate(),
      adicional3:"",
      fechaAdicional3:this.initialDate(),
      adicional4:"",
      fechaAdicional4:this.initialDate(),
      idFactura:0,
      uuid:"",
      idMoneda:0,
      idIva:0,
      importeIva:0.0000,
      tasaIsr:0,
      importeIsr:0.0000,
      tasaIsrIva:0,
      importeIsrIva:0.0000,
      importeTotal:0.0000,
      importeSubtotal:0.0000,
    }
  }
  closeModalEntradas(){
    this.modalReference.close();
    this.filtrosEntradas.de = "";
    this.filtrosEntradas.hasta = "";
    this.entradas = []
  }

  setDatosFactura(data){
    this.objAdicional.idFactura = data.idFactura;
    this.objAdicional.uuid = data.uuid;
    this.objAdicional.adicional1 = data.folioFactura;
    this.objAdicional.idMoneda = data.idMoneda;
    this.objAdicional.fechaAdicional1 = this.datepipe.transform(data.fechaFactura,'yyyy-MM-dd');
    this.objAdicional.idIva = data.idIva;
    this.objAdicional.importeSubtotal = data.importeSubtotal;
    this.objAdicional.importeIva = data.importeIva;
    this.objAdicional.importeIsr = data.importeIsr;
    this.objAdicional.importeIsrIva = data.importeIsrIva;
    this.objAdicional.tasaIsr = data.tasaIsr;
    this.objAdicional.tasaIsrIva = data.tasaIsrIva;
    this.objAdicional.importeTotal = data.importeTotal;


  }
public valor = "Entrada";
  guardarCxp(){
    for (const iterator of this.tiposcxp) {
      if (this.objCuenta.idTipoCxp === iterator.idTipoCxp) {
        this.valor = iterator.descripcion;
      }
    }
    if(this.nacionalidad == 1){
      var z = this.objCuenta.fechaAdicional1.split('-');
      let x = undefined;
      x = new Date(Number.parseInt(z[0]), Number.parseInt(z[1])-1, 1);
      var fechaActual = new Date(x);
      var daysInMonth = new Date(new Date(z.toString()).getFullYear(), Number(Number(new Date(z.toString()).getMonth()))+1, 0).getDate();
      var numDias = daysInMonth;
      var work = fechaActual.setDate(numDias);
      var fechaHoy = this.objCuenta.fecha;
      var hoy = this.datepipe.transform(fechaHoy,'yyyy-MM-dd');
      var comparar = this.datepipe.transform(work,'yyyy-MM-dd');

      if(hoy > comparar){
        swal.fire('','La factura '+this.objCuenta.adicional+' tiene más de 30 días de haberse emitido','warning')
        return;
      }
    }
    if(this.objCuenta.idMoneda == 1){
      if(this.objCuenta.paridad < 1){
        swal.fire('','El tipo de cambio es incorrecto','warning');
        return;
      }
    }
    //this.consultarSaldo();

    if(this.objCuenta.idTipoCxp != null || this.objCuenta.idTipoMovto != null || this.objCuenta.idTipoMovto!="0" || this.objCuenta.idProveedor != null || this.objCuenta.importeTotal != null || this.objCuenta.importeTotal != 0){
    this.cuentasPagar.guardarProvision(this.objCuenta).subscribe((data: any) => {
    if (data.data.errorMessage == null) {
      if(data.data.mensaje == null){
        swal.fire(
          '',
          'Datos guardados correctamente',
          'success'
        );
        this.router.navigate(['admcxpa004mw/admcxpa004mw']);
        this.objCuenta = {
          folio:"",
          id:0,
          idTipoCxp:0 as number,
          idTipoMovto:"",
          folioProveedor:"",
          idProveedor:"",
          nombreProveedor:"",
          fecha:"",
          documento:"",
          idDiasCredito:0,
          idMoneda:0,
          importeSubtotal:0.0000,
          paridad:0.0000,
          idIva:0,
          importeIva:0.0000,
          tasaIsr:0,
          importeIsr:0.0000,
          tasaIsrIva:0,
          importeIsrIva:0.0000,
          otrosImportes:0.0000,
          otrosExentos:0.0000,
          otrasRetenciones:0.0000,
          importeTotal:0.0000,
          cargo:0,
          abono:0,
          saldo:0,
          adicional:"",
          adicional1:"",
          fechaAdicional1:"",
          adicional2:"",
          fechaAdicional2:"",
          adicional3:"",
          fechaAdicional3:"",
          adicional4:"",
          fechaAdicional4:"",
          flete:false,
          idFactura:0,
          uuid:"",
          idRepetitivo:0,
          nombreRepetitivo:"",
          idProvision:0
        };
      }else{
        swal.fire('',data.data.mensaje,'warning');
      }
    } else {
      swal.fire(
        '',
        'Ocurrió un error al tratar de guardar los datos ' +
          data.data.errorMessage,
        'error'
      );
    }
  },
  (error) => {
    swal.fire(
      'Datos ',
      ' Ocurrió un Error al Momento de Guardar la cuenta por pagar' +
        ' Favor de Comunicarse con el Área de Informática y Generar un Reporte de Fallas,' +
        ' <strong>Código de Error: ' +
        error.error +
        '</strong>',
      'error'
    );
  }
  );
    }else{
      swal.fire('','hay datos pendientes de capturar','warning')
    }
    }
    public ivaGenerado:any;
    onPercentChange(percent: any) {
      for (const iterator of this.iva) {
        if (this.objCuenta.idIva === iterator.idIva) {
          this.ivaGenerado = iterator.valorIva;
        }
      }
      if(this.objCuenta.importeSubtotal !=null){
        var subtotal=0, total =0, isr=0,isrIva =0, iva =0;
        iva = Number(Number(this.objCuenta.importeSubtotal)+Number(this.objCuenta.otrosImportes))* Number(Number(this.ivaGenerado)/100);
        subtotal = Number(this.objCuenta.importeSubtotal)+Number(iva);
        isr = Number(this.objCuenta.importeSubtotal)* Number(Number(this.objCuenta.tasaIsr)/100);
        isrIva = Number(this.objCuenta.importeSubtotal) * Number(Number(this.objCuenta.tasaIsrIva)/100);
        total = Number(subtotal) - Number(isr) - Number(isrIva);
        total = Number(total) + Number(this.objCuenta.otrosImportes);
        this.objCuenta.importeIsr = Number(isr.toFixed(4));
        this.objCuenta.importeIva = Number(iva.toFixed(4));
        this.objCuenta.importeIsrIva = Number(isrIva.toFixed(4));
        this.objCuenta.importeTotal = Number(total.toFixed(4));
      }
    }

    initialDate(): string {
      let date = new Date();
      let day = date.getDate().toString();
      let month = (1 + date.getMonth()).toString();
      let year = date.getFullYear().toString();

      day.length == 1 ? day = "0" + day : null;

      month.length == 1 ? month = "0" + month : null;

      return year + "-" + month + "-" + day;
    }
    goToTable(){
      this.router.navigate(['admcxpa004mw/admcxpa004mw']);
    }
public fadicional1:any;
    fechaAdicional1(event:KeyboardEvent){
      if(event.key != "" && event.key != null && event.key != " " && event.key !="Backspace" && event.key != "ArrowDown" && event.key != "ArrowUp" && event.key != "ArrowLeft" && event.key != "ArrowRight"){
        this.fadicional1 = true;

      }else{
        this.fadicional1 = false;
      }

    }

    public fadicional2:any;
    fechaAdicional2(event){

      if(event.key != "" && event.key != null && event.key != " "){
        this.fadicional2 = true;

      }else{
        this.fadicional2 = false;
        this.objCuenta.fechaAdicional3 ="";
      }
    }
    public fadicional3:any;
    fechaAdicional3(event){

      if(event.key != "" && event.key != null && event.key != " "){
        this.fadicional3 = true;

      }else{
        this.fadicional3 = false;
        this.objAdicional.fechaAdicional4 = "";
      }

    }

    getDiasCredito() {
      this.cuentasPagar.getDiasCredito().subscribe(
        (data: any) => {
          if(data.data.length > 0){
          this.diasCredito = data.data;
          }else{
            this.diasCredito = [];
          }
        },
        (error) => {
          swal.fire(
            'Error',
            'Ocurrió un Error al Momento de Cargar los dias de crédito, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
            error.error +
            '</strong>',
            'error'
          );
        }
      );
    }
public active:any
public isBuscar:any
    selectItem(e){
      for (const iterator of this.tiposcxp) {
        if (this.objCuenta.idTipoCxp === iterator.idTipoCxp) {
          if(iterator.descripcion == "Entradas"){
            this.valor = "Entrada";
            this.isBuscar = true;
            this.active = true;
            this.objCuenta.paridad = Number(Number(1).toFixed(4));
            //this.consultarEntradas();
          }else if(iterator.descripcion == "Orden de Compra"){
            this.valor = "Orden de Compra";
            this.active = true;
            this.objCuenta.paridad = Number(Number(1).toFixed(4));
            this.isBuscar = true;
          }else if(iterator.descripcion == "Otras Referencias"){
            this.valor = "Otras referencias";
            this.active = true;
            this.isBuscar = false;
            //this.obtenerTipoCambio();
          }else if(iterator.descripcion == "Orden de Pago"){
            this.valor = "Orden de Pago";
            this.active = false;
            this.isBuscar = false;
          }else if(iterator.descripcion == "Fletes"){
            this.valor = "Fletes";
            this.active = false;
            this.isBuscar = false;
          }
        }
      }
    }
public monedaValor :any;
    obtenerTipoCambio(){
      for (const iterator of this.moneda) {
        if (this.objCuenta.idMoneda === iterator.idMoneda) {
          this.monedaValor = iterator.descripcionMoneda;
        }
      }
      this.cuentasPagar.obtenerTipoCambio(this.objCuenta.fecha).subscribe((success:any) =>{
        if(this.objCuenta.idMoneda == 0){
          this.objCuenta.paridad = 1;
        }else{

            if(this.objCuenta.idMoneda == 1){
              if(success.data.length > 0){
              this.objCuenta.paridad = success.data[0].paridad;
              if(this.objCuenta.paridad == null){
                swal.fire('','No se encontró tipo de cambio para esta fecha','warning');
                this.objCuenta.paridad = 0;
              }
            }else{
              swal.fire('','No se encontró tipo de cambio para esta fecha','warning');
            }

          }
        }

      }, Error => {
        swal.fire('Error!', 'Error al llamar servicios ' + Error, 'error');

      });
    }

    async aceptar(){
      if(this.valor == "Orden de compra"){
        if(this.saldo <= this.objAdicional.importeSubtotal){
          swal.fire('','El importe de la factura no coincide con el de la O.C','warning');
          return;
        }else{
          this.objCuenta.importeSubtotal = this.objAdicional.importeSubtotal;
          //Guarda el importe total de la factura como el abono
          this.objCuenta.abono = this.objAdicional.importeTotal;
        }
      }else if(this.valor == "Entrada"){
        if(this.objCuenta.importeTotal < this.objAdicional.importeTotal){
          swal.fire('','El importe de la factura no coincide con el de la entrada','warning')
        }else{
          this.objCuenta.importeSubtotal = this.objAdicional.importeSubtotal;
          this.objCuenta.importeTotal = this.objAdicional.importeTotal;
        }
      }

      if(this.objAdicional.idMoneda != this.objCuenta.idMoneda){
        swal.fire('','La moneda seleccionada no coincide con el de la factura','warning');
        return;
      }else{
        this.objCuenta.idMoneda = this.objAdicional.idMoneda;
      }
      if(this.objCuenta.idIva != this.objAdicional.idIva){
        swal.fire('','La tasa de IVA de la orden de compra no coincide con el de la factura','warning');
        return;
      }else{
        this.objCuenta.idIva = this.objAdicional.idIva;
      }
      this.objCuenta.adicional = this.objAdicional.adicional1;
      this.objCuenta.adicional1 = this.objAdicional.adicional1;
      this.objCuenta.fechaAdicional1 = this.objAdicional.fechaAdicional1;
      if(this.objAdicional.adicional2 != "" || this.objAdicional.adicional2 != null){
        this.objCuenta.fechaAdicional2 = this.objAdicional.fechaAdicional2;
      }
      if(this.objAdicional.adicional3 != "" || this.objAdicional.adicional3 != null){
        this.objCuenta.fechaAdicional3 = this.objAdicional.fechaAdicional3;
      }
      if(this.objAdicional.adicional4 != "" || this.objAdicional.adicional4 != null){
        this.objCuenta.fechaAdicional4 = this.objAdicional.fechaAdicional4;
      }
      this.objCuenta.uuid = this.objAdicional.uuid;
      this.objCuenta.idFactura = this.objAdicional.idFactura;
      this.objCuenta.tasaIsr = this.objAdicional.tasaIsr;
      this.objCuenta.tasaIsrIva = this.objAdicional.tasaIsrIva;
      this.objCuenta.importeIva = this.objAdicional.importeIva;
      this.objCuenta.importeIsr = this.objAdicional.importeIsr;
      this.objCuenta.importeIsrIva = this.objAdicional.importeIsrIva;

      //valida que si el proveedor es nacional, haya enviado facturas al portal
      if(this.nacionalidad == 1){
        const valor = await  this.cuentasPagar.getProveedorPortal(this.objCuenta.folio,this.objCuenta.folioProveedor,this.objCuenta.uuid);
        if( valor.data && valor.data.length > 0){
          const factura = await this.cuentasPagar.getFacturaPortal(this.objAdicional.idFactura,this.objCuenta.idProveedor,this.objCuenta.uuid)
          if(factura.data && factura.data.length == 0){
            swal.fire('','La factura '+this.objCuenta.adicional1+' No ha sido enviada al portal','warning');
            return;
          }
        }
      }
      this.closeModal();

    }

    //Valida que el proveedor tenga asignada una cuenta contable 201
    validarProveedor(){
      if(this.ValidaCuentacontable201()){
        this.guardarCxp();
      }else{
        swal.fire('','El proveedor no tiene Cuenta contable 201, para continuar favor de capturarla en modulo generacion de cuentas contables(Fin015MF)','warning')
      }
    }

    public validator:any;
    async ValidaCuentacontable201():Promise<any>{
      const valor = await  this.cuentasPagar.getCuenta201(this.objCuenta.idMoneda,this.objCuenta.folioProveedor);
      if( valor.data && valor.data.length > 0){
        return true;
      }else{
        return false;
      }
    }
    public saldo:any;
    async consultarSaldo():Promise<any>{
      this.listarProvisiones()
      this.filtrosOc.idProveedor = this.objCuenta.idProveedor;
      const valor = await this.cuentasPagar.consultarSaldoOc(this.filtrosOc);
      if( valor.data && valor.data.length > 0){
        if(valor.data[0] !== null){
          if(valor.data[0].saldo === 0){
            swal.fire('','La O.C no tiene saldo','warning');
            return;
          }else{
            swal.fire('','La O.C '+this.filtrosOc.folio+' tiene saldo pendiente','warning');
            var iva, ivacalculado;
            for (const iterator of this.iva) {
              if (this.objCuenta.idIva === iterator.idIva) {
                 iva = iterator.valorIva;
              }
            }
            this.saldo = valor.data[0].saldo;
            this.objCuenta.importeTotal = this.saldo;
            ivacalculado = 1+ Number(iva)/100;
            this.objCuenta.importeSubtotal = Number(Number(Number( this.objCuenta.importeTotal)/ivacalculado).toFixed(4));
            this.objCuenta.importeIva = Number(Number(this.objCuenta.importeSubtotal* iva/100).toFixed(4));
          }
        }

      }else{
       swal.fire('','La O.C no tiene saldo','warning');
      }
    }

    CargarIvas() {
      this.facturasProveedor.GetPorcentajesIva().subscribe(
        (data: any) => {
          this.iva = data.data;

        },
        (error) => {
          swal.fire(
            'Error',
            'Ocurrió un Error al Momento de Cargar las tasas de IVA, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
            error.error +
            '</strong>',
            'error'
          );
        }
      );
    }

    buscarOc(){
      this.filtrosOc.folio = this.objCuenta.documento;

      this.cuentasPagar.getOc(this.filtrosOc).subscribe((success:any) =>{
        if(success.data.length > 0){

          this.objCuenta.idProveedor = success.data[0].idProveedor;
          this.consultarSaldo();
          this.listarProvisiones()
          this.objCuenta.folioProveedor = success.data[0].folioProveedor;
          this.objCuenta.nombreProveedor = success.data[0].nombreProveedor;
          //this.objCuenta.importeSubtotal = success.data[0].importeSubtotal;
          this.objCuenta.idIva = success.data[0].idIva;
          this.objCuenta.importeIva = success.data[0].importeIva;
          this.objCuenta.importeTotal = this.saldo;
          this.objCuenta.idMoneda = success.data[0].idMoneda;
          this.objCuenta.paridad = success.data[0].paridad;

        }else{
          swal.fire('','No se encontró ninguna OC relacionada a ese folio','warning');
        }
      }, Error => {
        swal.fire('Error!', 'Error al llamar servicios ' + Error, 'error');

      });
    }

    seleccionar(e){
      this.objCuenta.idRepetitivo = e.data.idRepetitivo;
      this.objCuenta.nombreRepetitivo = e.data.nombreRepetitivo;
      this.mdlRepetitivo.closeModal();
    }

    public repetitivo:any = "";
    cargarRepetitivos() {
      this.cuentasPagar.listarRepetitivos(this.repetitivo).subscribe(
        (data: any) => {
          this.datos = data.data;

        },
        (error) => {
          swal.fire(
            'Error',
            'Ocurrió un Error al Momento de Cargar los repetitivos, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
            error.error +
            '</strong>',
            'error'
          );
        }
      );
    }

    consultarEntradas(){
      if(this.objCuenta.documento == ""){
        this.filtrosEntradas.folio = this.filtrosEntradas.folio;
      }else{
        this.filtrosEntradas.folio = this.objCuenta.documento;
      }
      this.filtrosEntradas.idProveedor = this.objCuenta.idProveedor;

      this.cuentasPagar.consultarEntradas(this.filtrosEntradas).subscribe((success:any) =>{
        this.entradas = success.data;
        console.log(this.entradas)
        if(this.objCuenta.documento != ""){
          this.objCuenta.importeSubtotal = this.entradas[0].importeSubtotal;
          this.objCuenta.idIva = this.entradas[0].idIva;
          this.objCuenta.importeIva = this.entradas[0].importeIva;
          this.objCuenta.importeTotal = this.entradas[0].importeTotal;
          this.objCuenta.idProveedor = this.entradas[0].idProveedor;
          this.listarProvisiones()
          this.objCuenta.folioProveedor = this.entradas[0].folioProveedor;
          this.objCuenta.nombreProveedor = this.entradas[0].nombreProveedor;
          this.objCuenta.idMoneda = this.entradas[0].idMoneda;
          this.objCuenta.paridad = this.entradas[0].paridad;
          this.objCuenta.idDiasCredito = this.entradas[0].idDiasCredito;
        }
      },
      (error)=>{
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar las entradas, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      })
    }

    seleccionarEntrada(e){
      console.log(e);
      this.objCuenta.documento = e.data.folioEntrada;
      this.objCuenta.importeTotal = e.data.importeTotal;
      this.objCuenta.importeSubtotal = e.data.importeSubtotal;
      this.objCuenta.idIva = e.data.idIva;
      this.objCuenta.importeIva = e.data.importeIva;
      this.objCuenta.idProveedor = e.data.idProveedor;
      this.listarProvisiones();
      this.objCuenta.nombreProveedor = e.data.nombreProveedor;
      this.objCuenta.folioProveedor = e.data.folioProveedor;
      this.objCuenta.idMoneda = e.data.idMoneda;
      this.objCuenta.idDiasCredito = e.data.idDiasCredito;
      this.closeModalEntradas();
    }

    calculos(){
      if(this.valor == "Entrada"){

      }else{
        return;
      }
    }


    select(){
      if(this.valor == "Entrada"){
        if(this.objCuenta.documento == "" || this.objCuenta.documento == null){
          this.openModalEntradas();
        }else{
          this.consultarEntradas();
        }
      }else if(this.valor === "Orden de Compra"){
        this.buscarOc();
      }
    }

    fechaXvDias(){
      let hoy = new Date();
      let quincedias = 1000 *60 *60*24*15;
      let resta = hoy.getTime() -quincedias;
      let fechaquince = new Date(resta);
      let fechaInicio = this.datepipe.transform(fechaquince,'yyyy-MM-dd');
      return fechaInicio;
    }

    listarProvisiones(){
      this.filtrosProvisiones.idProveedor = this.objCuenta.idProveedor;
      this.cuentasPagar.listarProvisiones(this.filtrosProvisiones).subscribe((success:any) =>{
        this.provisiones = success.data;
        console.log(this.provisiones)
      },
      (error)=>{
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar las provisiones, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      })
    }
    public contador:number;
    seleccionarProvisiones(e){
      for (const item of this.provisiones) {
        if(e.data.idProvision === item.idProvision){
          item.provision = true;
          this.objCuenta.idProvision = e.data.idProvision;

        }else{
          item.provision = false;

        }
      }
      this.gridProvisiones.refreshData();

    }

  }
