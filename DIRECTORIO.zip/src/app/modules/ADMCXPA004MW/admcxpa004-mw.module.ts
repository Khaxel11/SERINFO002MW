import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../../shared/shared.module';

import { ADMCXPA004MWRoutingModule } from './admcxpa004-mw-routing.module';
import { ADMCXPA004MWComponent } from './pages/admcxpa004-mw/admcxpa004-mw.component';
import { ADMCXPA004MWAddComponent } from './pages/admcxpa004-mwadd/admcxpa004-mwadd.component';


@NgModule({
  declarations: [ADMCXPA004MWComponent, ADMCXPA004MWAddComponent],
  imports: [
    CommonModule,
    ADMCXPA004MWRoutingModule,
    SharedModule
  ]
})
export class ADMCXPA004MWModule { }
