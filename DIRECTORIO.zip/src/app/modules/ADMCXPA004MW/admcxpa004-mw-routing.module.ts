import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ADMCXPA004MWComponent} from './pages/admcxpa004-mw/admcxpa004-mw.component';
import {ADMCXPA004MWAddComponent} from './pages/admcxpa004-mwadd/admcxpa004-mwadd.component';

const routes: Routes = [
  { path: 'admcxpa004mw', component: ADMCXPA004MWComponent },
  { path: 'admcxpa004mw/:mode', component: ADMCXPA004MWAddComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ADMCXPA004MWRoutingModule { }
