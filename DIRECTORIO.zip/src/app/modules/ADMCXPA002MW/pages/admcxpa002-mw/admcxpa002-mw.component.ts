import { Component, OnInit, ViewChild } from '@angular/core';
import { FacturasProveedoresService} from '../../../../services/CuentasXPagar/FacturasProveedores.service';
import { iFacturaProveedor } from '../../../../models/CuentasXPagar/iFacturaProveedor';
import { IClaveDescripcion } from '../../../../models/CuentasXPagar/IClaveDescripcion';
import swal from 'sweetalert2';

@Component({
  selector: 'app-admcxpa002-mw',
  templateUrl: './admcxpa002-mw.component.html',
  styleUrls: ['./admcxpa002-mw.component.css']
})
export class ADMCXPA002MWComponent implements OnInit {

    // PPricipal
    @ViewChild('gridPrincipal') private Grid: any;
    columnDefs: any;
    DatosGrid: Array<iFacturaProveedor> = [];
    Datos = {};
    DataTiposMoneda : Array<IClaveDescripcion>;
    date: Date = null;
    DataResult:any;

    // Parametros SP
    DatosRangoFechas = {
      FechaIni: '',
      FechaFin: ''
    }
      
    // Filtros
    FiltrosBusquedaFactura = {
      FechaIni: null,
      FechaFin: null,
      Serie:'',
      Folio:'',
      Factura:'',
      UUID:'',
      RazonSocial:'',
      IdMoneda: 0

    }

    // Datos Entidad
    DatFormulario: iFacturaProveedor = {
      admcxpadaT001_ID:0,
      admcxpadaT001_Serie:'',
      admcxpadaT001_Folio:'',
      admcxpadaT001_Factura:'',
      admcxpadaT001_UUID:'',
      admcxpadaT001_OrdenCompra:'',
      admcxpadaT001_FechaFactura:null,
      admcxpadaT001_FechaCarga :null,
      admcompcaT002_ID:0,
      admcompcaT002_RazonSocial:'',
      admcontcaT020_IdMoneda:-1,
      moneda:'',
      admcxpadaT001_TipoCambio:1,
      admcxpadaT001_ImporteSubtotal:0,
      fcocaT016_IdIva:0,
      admcxpadaT001_ImporteIVA:0,
      admcxpadaT001_TasaISR:0,
      admcxpadaT001_ImporteISR:0,
      admcxpadaT001_TasaISRIVA:0,
      admcxpadaT001_ImporteISRIVA:0,
      admcxpadaT001_ImporteTotal:0,
      admcxpadaT001_Usuario:'',
      admcxpadaT001_AplicadoCxP:false,
      admcxpadaT001_FechaAplicadoCxP:null,
      admcxpadaT001_UsuarioAplicoCxP:'',
      admcxpadaT001_AplicadoTesoreria:false,
      admcxpadaT001_FechaAplicadoTesoreria:null,
      admcxpadaT001_UsuarioAplicoTesoreria:'',
      admcxpadaT001_Activo:false,
      admcxpadaT001_FechaInsert:null,
      admcxpadaT001_UsuarioInsert:'',
      admcxpadaT001_FechaModificacion:null,
      admcxpadaT001_UsuarioModifica:'',
      admcxpadaT001_FechaEliminacion:null,
      admcxpadaT001_UsuarioElimina:'',
      tipoAccion: ''
    };
  
    

    // Modal
    @ViewChild('mdl') private mdl: any;
    //@ViewChild('mdlProveedor') private mdlProveedor: any;
    
    Titulo = '';
    IconoTitulo = '';
    TipoAccion = 'A';
    
    
         
  SetFirstAndLastDayOfMonth():void{
    var date = new Date();
    this.DatosRangoFechas.FechaIni =  new Date(date.getFullYear(), date.getMonth(), 1).toISOString().substr(0, 10);
    this.DatosRangoFechas.FechaFin =   date.toISOString().substr(0, 10);
  }


    
    constructor(public Servicio: FacturasProveedoresService) {
      
    //this.DatFormulario.admcontcaT020_IdMoneda = -1;
    this.columnDefs = [
      {
        headerName: 'ADMCXPADAT001_ID',
        field: 'admcxpadaT001_ID',
        flex: 2,
        minWidth: 80,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_Serie',
        field: 'admcxpadaT001_Serie',
        flex: 2,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_Folio',
        field: 'admcxpadaT001_Folio',
        flex: 3,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'Factura',
        field: 'admcxpadaT001_Factura',
        flex: 4,
        maxWidth: 100,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'UUID',
        field: 'admcxpadaT001_UUID',
        flex: 4,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'ADMCXPADAT001_OrdenCompra',
        field: 'admcxpadaT001_OrdenCompra',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      { 
        headerName: 'Fecha Factura',
        field: 'admcxpadaT001_FechaFactura',
        flex: 3,
        maxWidth: 140,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        cellRenderer: (data) => {
          return data.value ? (new Date(data.value)).toLocaleDateString('en-GB') : '';
        }
      },
      { 
        headerName: 'ADMCXPADAT001_FechaCarga',
        field: 'admcxpadaT001_FechaCarga',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
        cellRenderer: (data) => {
          return data.value ? (new Date(data.value)).toLocaleDateString('en-GB') : '';
        }
        
      },
      { // Codigo + " - " + Nombre AS Proveedor
        headerName: 'ID Prov',
        field: 'admcompcaT002_ID',
        flex: 3,
        maxWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      { // Codigo + " - " + Nombre AS Proveedor
        headerName: 'Proveedor',
        field: 'admcompcaT002_RazonSocial',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {//Moneda (MXN o USD que viene en el catálogo de monedas)
        headerName: 'IdMoneda',
        field: 'admcontcaT020_IdMoneda',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {//Moneda (MXN o USD que viene en el catálogo de monedas)
        headerName: 'Moneda',
        field: 'moneda',
        flex: 3,
        maxWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'ADMCONTCAT020_TipoCambio',
        field: 'admcxpadaT001_TipoCambio',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'SubTotal',
        field: 'admcxpadaT001_ImporteSubtotal',
        flex: 3,
        maxWidth: 140,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',

      },
      {
        headerName: 'FCOCAT016_IdIva',
        field: 'fcocaT016_IdIva',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_ImporteIVA',
        field: 'admcxpadaT001_ImporteIVA',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_TasaISR',
        field: 'admcxpadaT001_TasaISR',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_ImporteISR',
        field: 'admcxpadaT001_ImporteISR',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_TasaISRIVA',
        field: 'admcxpadaT001_TasaISRIVA',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_ImporteISRIVA',
        field: 'admcxpadaT001_ImporteISRIVA',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'Importe Total',
        field: 'admcxpadaT001_ImporteTotal',
        flex: 3,
        maxWidth: 140,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',

      },
      {
        headerName: 'ADMCXPADAT001_Usuario',
        field: 'admcxpadaT001_Usuario',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_AplicadoCxP',
        field: 'admcxpadaT001_AplicadoCxP',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'ADMCXPADAT001_AplicadoTesoreria',
        field: 'admcxpadaT001_AplicadoTesoreria',
        flex: 3,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
        hide: true,
      },
      {
        headerName: 'Editar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.GridEditar.bind(this),
          label: '<i class="fa fa-edit"></i>',
          class: 'btn btn-warning btn-sm',
        },
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
      {
        headerName: 'Eliminar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.GridEliminar.bind(this),
          label: '<i class="fa fa-trash"></i>',
          class: 'btn btn-danger btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
    ];
  }
 

 
  

  ngOnInit(): void {
    this.SetFirstAndLastDayOfMonth();
    this.LoadDataTiposMoneda();
    this.DatFormulario.admcontcaT020_IdMoneda = -1;
  }

  GridEditar(e): void {
    // this.TipoAccion = 'M';
    // this.IconoTitulo = 'fa fa-edit';
    // this.Datos = e.data;
    // this.mdl.openModal();
  }
  GridEliminar(e): void {
    // swal
    //   .fire({
    //     title: '¿Desea eliminar la factura?',
    //     text: e.data.admcxpadaT001_Factura,
    //     icon: 'warning',
    //     showCancelButton: true,
    //     confirmButtonColor: '#3085d6',
    //     cancelButtonColor: '#d33',
    //     confirmButtonText: 'Aceptar',
    //     cancelButtonText: 'Cancelar',
    //   })
    //   .then((result) => {
    //     if (result.isConfirmed) {
    //       this.Servicio.EliminarFacturasProveedores(e.data.admcxpadaT001_ID).subscribe(
    //         (data: any) => {
    //             swal.fire('', 'El registro fue eliminado', 'success');
    //             this.Grid.refreshData();
    //             this.ListarFacturasProveedores();
    //         },
    //         (error) => {
    //           swal.fire(
    //             'Datos ',
    //             'Ha Ocurrio un Error al Momento de Eliminar,' +
    //               ' Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas,' +
    //               ' <strong>Código de Error: ' +
    //               error.error +
    //               '</strong>',
    //             'error'
    //           );
    //         }
    //       );
    //     }
    //   });
  }


  // =================PPrincipal=================//
  btnBuscar(): void {
    this.Grid.refreshData();
  }
  btnAgregar(): void {
    this.TipoAccion = 'A';
    this.IconoTitulo = 'fa fa-plus';
    this.Datos = {};
     if(this.TipoAccion === 'A'){
      this.GetSiguienteId();
    }
    this.DatFormulario.admcontcaT020_IdMoneda = 0;
    //this.mdl.openModal();
  }
  KeyPressBuscar(e): void {
    if (e.keyCode === 13) {
      this.btnBuscar();
    }
  }
  // =================Modal=================//
  btnCerrarModal(): void{
    this.btnBuscar();
    this.mdl.closeModal();
  }


  GetSiguienteId(): void {
  
    this.Servicio.GetSiguienteId().subscribe(
      (data: any) => {
        this.DataResult = data.data;

        // Si regreso valorNumerico (tipo cambio), lo asignamos
        this.DatFormulario.admcxpadaT001_ID = (this.DataResult[0].valor > 0) ? Number(this.DataResult[0].valor) : 1;
        this.Datos = this.DatFormulario;
        this.mdl.openModal();
      },
      (error) => {

        swal.fire(
          'Error',
          'Ha Ocurrio un Error al Momento de buscar el siguiente Id Factura, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }

  // Le enviamo el modelo al SP para que cargue con los filtros indicados.
  ListarFacturasProveedores(): any {

    this.FiltrosBusquedaFactura.FechaIni = this.DatosRangoFechas.FechaIni;
    this.FiltrosBusquedaFactura.FechaFin = this.DatosRangoFechas.FechaFin;
    this.FiltrosBusquedaFactura.Serie = this.DatFormulario.admcxpadaT001_Serie;
    this.FiltrosBusquedaFactura.Folio = this.DatFormulario.admcxpadaT001_Folio;
    this.FiltrosBusquedaFactura.Factura = this.DatFormulario.admcxpadaT001_Factura;
    this.FiltrosBusquedaFactura.UUID = this.DatFormulario.admcxpadaT001_UUID;
    this.FiltrosBusquedaFactura.RazonSocial = this.DatFormulario.admcompcaT002_RazonSocial;
    this.FiltrosBusquedaFactura.IdMoneda = this.DatFormulario.admcontcaT020_IdMoneda;

    this.Servicio.ListarFacturasProveedores(this.FiltrosBusquedaFactura).subscribe(
      (data: any) => {
        this.DatosGrid = data.data
      },
      (error) => {
        swal.fire(
          'Error',
          'Ha Ocurrio un Error al Momento de Cargar las facturas, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    )
  }

  
  // cargar combo tupo de moneda
  LoadDataTiposMoneda() {
    // this.Servicio.GetListadoMonedas().subscribe(
    //   (data: any) => {
    //     this.DataTiposMoneda = data.data;
    //   },
    //   (error) => {
    //     swal.fire(
    //       'Error',
    //       'Ha Ocurrio un Error al Momento de Cargar Tipos de Moneda, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
    //       error.error +
    //       '</strong>',
    //       'error'
    //     );
    //   }
    // );
  }




    


  
}
