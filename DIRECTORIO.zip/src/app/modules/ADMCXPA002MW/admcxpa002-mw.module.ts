import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {SharedModule } from '../../shared/shared.module';
import { BlockUIModule } from 'ng-block-ui';


// routing.module
import { ADMCXPA002MWRoutingModule } from './admcxpa002-mw-routing.module';
// component
import { ADMCXPA002MWComponent } from './pages/admcxpa002-mw/admcxpa002-mw.component';
// Modal
import { MdlADMCXPA002MWComponent } from './components/mdl-admcxpa002-mw/mdl-admcxpa002-mw.component';
//import { MdlProveedorComponent } from './components/mdl-proveedor/mdl-proveedor.component';




@NgModule({
  declarations: [ ADMCXPA002MWComponent, MdlADMCXPA002MWComponent],
  imports: [
    CommonModule,
    ADMCXPA002MWRoutingModule,
    FormsModule,
    SharedModule,
    BlockUIModule.forRoot()
  ]
})
export class ADMCXPA002MWModule { }
