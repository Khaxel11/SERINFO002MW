import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { cloneDeep } from 'lodash-es';
//import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { IClaveDescripcion } from 'src/app/models/CuentasXPagar/IClaveDescripcion';
import { IDatosIva } from 'src/app/models/CuentasXPagar/iDatosIva';
import { iFacturaProveedor } from 'src/app/models/CuentasXPagar/iFacturaProveedor';
import { FacturasProveedoresService } from 'src/app/services/CuentasXPagar/FacturasProveedores.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-mdl-admcxpa002-mw',
  templateUrl: './mdl-admcxpa002-mw.component.html',
  styleUrls: ['./mdl-admcxpa002-mw.component.css']
})
export class MdlADMCXPA002MWComponent implements OnInit {


  @BlockUI() blockUI: NgBlockUI;
  @Input() TipoAccion = 'A';
  @Input() nameProveedor: string;

  IsNewFactura: boolean=false;
  IsProveedorEditable: boolean=false;
  
  
  @Input() set Datos(value: any) {

    this.IsNewFactura = (this.TipoAccion === 'A') ? true : false;
    this.IsProveedorEditable = (this.TipoAccion === 'M') ? true : false;

    if (Object.keys(value).length !== 0) {
      this.DatFormulario =  cloneDeep(value);

      this.DatFormulario.admcxpadaT001_FechaFactura = 
          (this.DatFormulario.admcxpadaT001_FechaFactura !== null) ? 
          this.datePipes.transform(this.DatFormulario.admcxpadaT001_FechaFactura, 'yyyy-MM-dd') : 
          this.objFecha.FechaFactura;
    }
  }


  @Output() ClickbtnCerrar = new EventEmitter<any>();
  @Output() guardado = new EventEmitter<any>();

  
    // Modal
    @ViewChild('mdlProveedor') public mdlProveedor: any;
    //modalRef: NgbModalRef;
    
    Titulo = '';
    IconoTitulo = '';

  
   // Datos Entidad

   DatFormulario: iFacturaProveedor = {
    admcxpadaT001_ID:0,
    admcxpadaT001_Serie:'',
    admcxpadaT001_Folio:'',
    admcxpadaT001_Factura:'',
    admcxpadaT001_UUID:'',
    admcxpadaT001_OrdenCompra:'',
    admcxpadaT001_FechaFactura:null,
    admcxpadaT001_FechaCarga :null,
    admcompcaT002_ID:0,
    admcompcaT002_RazonSocial:'',
    admcontcaT020_IdMoneda:0,
    moneda:'',
    admcxpadaT001_TipoCambio:1,
    admcxpadaT001_ImporteSubtotal:0,
    fcocaT016_IdIva:0,
    admcxpadaT001_ImporteIVA:0,
    admcxpadaT001_TasaISR:0,
    admcxpadaT001_ImporteISR:0,
    admcxpadaT001_TasaISRIVA:0,
    admcxpadaT001_ImporteISRIVA:0,
    admcxpadaT001_ImporteTotal:0,
    admcxpadaT001_Usuario:'',
    admcxpadaT001_AplicadoCxP:false,
    admcxpadaT001_FechaAplicadoCxP:null,
    admcxpadaT001_UsuarioAplicoCxP:'',
    admcxpadaT001_AplicadoTesoreria:false,
    admcxpadaT001_FechaAplicadoTesoreria:null,
    admcxpadaT001_UsuarioAplicoTesoreria:'',
    admcxpadaT001_Activo:false,
    admcxpadaT001_FechaInsert:null,
    admcxpadaT001_UsuarioInsert:'',
    admcxpadaT001_FechaModificacion:null,
    admcxpadaT001_UsuarioModifica:'',
    admcxpadaT001_FechaEliminacion:null,
    admcxpadaT001_UsuarioElimina:'',
    tipoAccion: ''
  };

  // Declaraciones
  objFecha = {FechaFactura: '', FechaHoy: ''}
  DataTiposMoneda : Array<IClaveDescripcion>;
  DataPorcentajeIva : Array<IDatosIva>;
  UUID: string = ''
  DataResult:any


  constructor(public Servicio: FacturasProveedoresService, public datePipes: DatePipe/*, private modalService: NgbModal*/) {}


  ngOnInit(): void {
    this.SetDates();
    this.GetListadoMonedas();
    this.GetPorcentajesIva();
    // if(this.TipoAccion === 'A'){
    //   this.GetSiguienteId()
    // }
    
  }

  btnGuardar(): void {
    
    // Si regresa texto es que no paso las validaciones
    if(this.ValidaciondatosObligatorios() !== ''){
      return;
    }

    // Se valida UUID antes de porceder a Guardar la factura, cuando es Nueva Factura
    if(this.TipoAccion === 'A'){
      this.BuscaUUID();
    }else{
      this.Agregar();
    }
  }

  btnCerrar(): void {
    this.Limpiar();
    this.ClickbtnCerrar.emit();
  }



  ValidaciondatosObligatorios(): string{
    let message: string = '';
    if(this.DatFormulario.admcompcaT002_ID === 0){
      message = 'PROVEEDOR';
    }
    if(this.DatFormulario.admcxpadaT001_Folio === ''){
      message += ', FOLIO';
    }
    if(this.DatFormulario.fcocaT016_IdIva === 0){
      message += ', IVA';
    }
    if(this.DatFormulario.admcxpadaT001_TipoCambio <= 0){
      message += ', TIPO DE CAMBIO DEBE SER MAYOR QUE 0';
    }
    if(this.DatFormulario.admcxpadaT001_ImporteTotal <= 0){
      message += ', IMPORTE TOTAL DEBE SER MAYOR QUE 0';
    }

    swal.fire('','Falto indicar ' + message ,'error');
    return message;
  }
      
  Agregar(): void {


    
    this.DatFormulario.tipoAccion = this.TipoAccion;
    this.DatFormulario.admcxpadaT001_ImporteSubtotal = Number(this.DatFormulario.admcxpadaT001_ImporteSubtotal);
    this.DatFormulario.admcxpadaT001_TipoCambio = Number(this.DatFormulario.admcxpadaT001_TipoCambio);
    this.DatFormulario.admcxpadaT001_TasaISR = Number(this.DatFormulario.admcxpadaT001_TasaISR)/100;
    this.DatFormulario.admcxpadaT001_TasaISRIVA = Number(this.DatFormulario.admcxpadaT001_TasaISRIVA)/100;
    
    this.Servicio.GuardarFacturasProveedores(this.DatFormulario).subscribe(
      (data: any) => {
          this.guardado.emit();
          swal.fire('','Los Datos fueron agregados correctamente','success');
          this.blockUI.stop();
          this.Limpiar();
          this.btnCerrar();
      },
      (error) => {
        this.blockUI.stop();
        swal.fire(
          'Datos ',
          'Ha Ocurrido un Error al Momento de Agregar,' +
            ' Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas,' +
            ' <strong>Código de Error: ' +
            error.error +
            '</strong>',
          'error'
        );
      }
    );
    
  }

  SetDates():void{
    var date = new Date();
    this.objFecha.FechaFactura = this.datePipes.transform(date, 'yyyy-MM-dd');//.toISOString().substr(0, 10);
  }

  SetValorIva(Tasa: string):void{
      
      this.DataPorcentajeIva.forEach(element => {
        if(element.idIva === this.DatFormulario.fcocaT016_IdIva){
          this.DatFormulario.admcxpadaT001_ImporteIVA = this.DatFormulario.admcxpadaT001_ImporteSubtotal * element.valorIva/100;
        }
      });
    
      this.DatFormulario.admcxpadaT001_ImporteISR = this.DatFormulario.admcxpadaT001_ImporteSubtotal * this.DatFormulario.admcxpadaT001_TasaISR/100;
      this.DatFormulario.admcxpadaT001_ImporteISRIVA = this.DatFormulario.admcxpadaT001_ImporteSubtotal * this.DatFormulario.admcxpadaT001_TasaISRIVA/100;
    

    this.DatFormulario.admcxpadaT001_ImporteTotal =
      Number(this.DatFormulario.admcxpadaT001_ImporteSubtotal) +
      Number(this.DatFormulario.admcxpadaT001_ImporteIVA) +
      Number(this.DatFormulario.admcxpadaT001_ImporteISR) +
      Number(this.DatFormulario.admcxpadaT001_ImporteISRIVA);

  }

  



  FormarClaveFactura() {
    //if(this.DatFormulario.admcxpadaT001_Serie !== '' && this.DatFormulario.admcxpadaT001_Folio !== '')
      this.DatFormulario.admcxpadaT001_Factura = this.DatFormulario.admcxpadaT001_Serie + this.DatFormulario.admcxpadaT001_Folio;
  }


 
    

  // Validar si existe el UUID
   BuscaUUID(): void {

    this.UUID = this.DatFormulario.admcxpadaT001_UUID;
    this.Servicio.BuscaUUID(this.UUID).subscribe(
      (data: any) => {
        this.DataResult = data.data;

        // Si regreso Cadena es que encontro el UUID ya registrado en otra factura NO PODEMOS CONTINUAR
        if(this.DataResult[0].cadena.length > 0){
          swal.fire('AVISO!','<strong>Mensaje: ' + this.DataResult[0].cadena +'</strong>','warning');
        }else{
          this.blockUI.start('Cargando...');
          this.Agregar()
        }
    
      },
      (error) => {

        swal.fire(
          'Error',
          'Ha Ocurrio un Error al Momento de validar UUID, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }


  // cargar combo tupo de moneda
  GetListadoMonedas() {
    this.Servicio.GetListadoMonedas().subscribe(
      (data: any) => {
        this.DataTiposMoneda = data.data;
      },
      (error) => {
        swal.fire(
          'Error',
          'Ha Ocurrio un Error al Momento de Cargar Tipos de Moneda, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }

    
  // Validar si existe el UUID
  GetTipoCambio(): void {

    let inputTipoCambio = <HTMLInputElement>document.getElementById('admcxpadaT001_TipoCambio');

    // default $1.0
    this.DatFormulario.admcxpadaT001_TipoCambio = 1.0;
    inputTipoCambio.disabled = true;
    

    // si moneda es diferente a PESO MXN
    if (this.DatFormulario.admcontcaT020_IdMoneda > 0) {

      inputTipoCambio.disabled = false;
      
      var hoy = new Date();
      this.objFecha.FechaHoy = hoy.toISOString().substr(0, 10);      

      this.Servicio.GetTipoCambio(this.objFecha.FechaHoy).subscribe(
        (data: any) => {
          this.DataResult = data.data;

          // Si regreso valorNumerico (tipo cambio), lo asignamos
          if (this.DataResult.length > 0) {
            this.DatFormulario.admcxpadaT001_TipoCambio = Number(this.DataResult[0].valor);
          }

        },
        (error) => {

          swal.fire(
            'Error',
            'Ha Ocurrio un Error al Momento de buscar el Tipo de Cambio, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
            error.error +
            '</strong>',
            'error'
          );
        }
      );
    }
  }


      // cargar combo tupo de moneda
      GetPorcentajesIva() {
        this.Servicio.GetPorcentajesIva().subscribe(
          (data: any) => {
            this.DataPorcentajeIva = data.data;
          },
          (error) => {
            swal.fire(
              'Error',
              'Ha Ocurrio un Error al Momento de Cargar Porcentajes de IVA, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
              error.error +
              '</strong>',
              'error'
            );
          }
        );
      }
 

    // =================Modal=================//
  
    AbrirModalProveedor(){
      this.mdlProveedor.openModal();
    }
       
    
    closeModal(){
      this.mdlProveedor.closeModal();
    }

    SetProveedorSelected(evt){
      this.DatFormulario.admcompcaT002_ID = evt.id;
      this.DatFormulario.admcompcaT002_RazonSocial = evt.descripcion;
    }




    Limpiar(): void {
      this.DatFormulario = {
        admcxpadaT001_ID:0,
        admcxpadaT001_Serie:'',
        admcxpadaT001_Folio:'',
        admcxpadaT001_Factura:'',
        admcxpadaT001_UUID:'',
        admcxpadaT001_OrdenCompra:'',
        admcxpadaT001_FechaFactura:null,
        admcxpadaT001_FechaCarga :null,
        admcompcaT002_ID:0,
        admcompcaT002_RazonSocial:'',
        admcontcaT020_IdMoneda:0,
        moneda:'',
        admcxpadaT001_TipoCambio:1,
        admcxpadaT001_ImporteSubtotal:0,
        fcocaT016_IdIva:0,
        admcxpadaT001_ImporteIVA:0,
        admcxpadaT001_TasaISR:0,
        admcxpadaT001_ImporteISR:0,
        admcxpadaT001_TasaISRIVA:0,
        admcxpadaT001_ImporteISRIVA:0,
        admcxpadaT001_ImporteTotal:0,
        admcxpadaT001_Usuario:'',
        admcxpadaT001_AplicadoCxP:false,
        admcxpadaT001_FechaAplicadoCxP:null,
        admcxpadaT001_UsuarioAplicoCxP:'',
        admcxpadaT001_AplicadoTesoreria:false,
        admcxpadaT001_FechaAplicadoTesoreria:null,
        admcxpadaT001_UsuarioAplicoTesoreria:'',
        admcxpadaT001_Activo:false,
        admcxpadaT001_FechaInsert:null,
        admcxpadaT001_UsuarioInsert:'',
        admcxpadaT001_FechaModificacion:null,
        admcxpadaT001_UsuarioModifica:'',
        admcxpadaT001_FechaEliminacion:null,
        admcxpadaT001_UsuarioElimina:'',
        tipoAccion: ''
      };
  
    }
  
}

