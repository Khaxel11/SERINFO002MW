import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ADMCXPA002MWComponent} from './pages/admcxpa002-mw/admcxpa002-mw.component';

const routes: Routes = [
  { path: 'admcxpa002mw', component: ADMCXPA002MWComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ADMCXPA002MWRoutingModule { }