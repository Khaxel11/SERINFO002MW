import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmorep016',
  templateUrl: './cmorep016.component.html',
  styleUrls: ['./cmorep016.component.css']
})
export class Cmorep016Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
