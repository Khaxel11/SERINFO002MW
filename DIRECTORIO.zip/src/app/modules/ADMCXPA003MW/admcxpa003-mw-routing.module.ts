import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ADMCXPA003MWComponent} from './pages/admcxpa003-mw/admcxpa003-mw.component';

const routes: Routes = [
  { path: 'admcxpa003mw', component: ADMCXPA003MWComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ADMCXPA003MWRoutingModule { }
