import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ADMCXPA003MWRoutingModule } from './admcxpa003-mw-routing.module';
import { ADMCXPA003MWComponent } from './pages/admcxpa003-mw/admcxpa003-mw.component';
import {SharedModule} from '../../shared/shared.module';

@NgModule({
  declarations: [
    ADMCXPA003MWComponent
  ],
  imports: [
    CommonModule,
    ADMCXPA003MWRoutingModule,
    SharedModule
  ]
})
export class ADMCXPA003MWModule { }
