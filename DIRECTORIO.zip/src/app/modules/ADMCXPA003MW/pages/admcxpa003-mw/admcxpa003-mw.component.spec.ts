import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ADMCXPA003MWComponent } from './admcxpa003-mw.component';

describe('ADMCXPA003MWComponent', () => {
  let component: ADMCXPA003MWComponent;
  let fixture: ComponentFixture<ADMCXPA003MWComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ADMCXPA003MWComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ADMCXPA003MWComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
