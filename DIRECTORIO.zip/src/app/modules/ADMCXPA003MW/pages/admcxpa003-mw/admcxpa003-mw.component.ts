import { Component, OnInit,ViewChild } from '@angular/core';
import { FacturasProveedorService } from '../../../../services/facturasProveedor';
import { FacturasProveedoresService } from '../../../../services/CuentasXPagar/FacturasProveedores.service';
import swal from 'sweetalert2';
import { TipoMovimientoService } from '../../../../services/tipo-movimiento.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { textChangeRangeIsUnchanged } from 'typescript';

@Component({
  selector: 'app-admcxpa003-mw',
  templateUrl: './admcxpa003-mw.component.html',
  styleUrls: ['./admcxpa003-mw.component.css']
})
export class ADMCXPA003MWComponent implements OnInit {
  @ViewChild('mdlProveedor') public mdlProveedor: any;
  @ViewChild('mdlBuscar') public mdlBuscar: any;
  @ViewChild('mdlProvision') public mdlProvision: any;
  @ViewChild('gridEjecutivo') public Grid: any;
  @ViewChild('gridProvisiones') public gridProvisiones: any;
  modalRef: NgbModalRef;
  modalReference: NgbModalRef;
  objProvision = {
    idProveedor:"",
    nombre:"",
    fecha:"",
    idMoneda:0,
    subtotal: 0.00 ,
    ivaGenerado: "",
    total:"",
    tipoCambio:0.00,
    ivaId:0,
    iva:0,
    idFactura:"",
    documento:"",
    idTipoMovto:0,
    factura:"",
    idProvision:0
  }
  public filtrosFactura = {
    filtro:"",
    startRow:0,
    endRow:0,
    fecha:"",
    fechaInicio:"",
    fechaFin:"",
    idProveedor:""
  };

  public filtrosBusqueda = {
    filtro:"",
    startRow:0,
    endRow:0,
    fechaInicio:"",
    fechaFin:""
  };
  columnDefs: any;
  columnas: any;
  moneda = [];
  movimiento =[];
  iva = [];
  activaCampos:any;
  datos =[];
  constructor(public factura:FacturasProveedorService,public facturasProv: FacturasProveedoresService, public movimientos: TipoMovimientoService, public modalService: NgbModal,public datepipe: DatePipe) { 
    this.columnDefs = [
      {
        headerName: 'Id',
        field: 'idFactura',
        flex: 2,
        minWidth: 80,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Factura',
        field: 'factura',
        flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      ,
      {
        headerName: 'Total',
        field: 'total',
        flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Seleccionar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.CargarDatosFactura.bind(this),
          label: '<i class="fa fa-check"></i>',
          class: 'btn btn-success btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      }
    ];

    this.columnas = [
      {
        headerName: 'Proveedor',
        field: 'descripcion',
        flex: 12,
        minWidth: 80,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-left',
      },
      {
        headerName: 'Factura',
        field: 'factura',
        flex: 5,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-left',
      },
      {
        headerName: 'Documento',
        field: 'documento'
        ,flex: 6,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-left',
      },
      {
        headerName: 'Fecha',
        field: 'fecha'
        ,flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Editar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.editar.bind(this),
          label: '<i class="fa fa-edit"></i>',
          class: 'btn btn-warning btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
      {
        headerName: 'Eliminar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.GridEliminar.bind(this),
          label: 
            '<i class="fa fa-trash"></i>',
          class: 'btn btn-danger btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
    ];
  }

  ngOnInit(): void {
    this.LoadDataTiposMoneda();
    this.filtrosBusqueda.fechaFin = this.initialDate();
    let hoy = new Date();
    let quincedias = 1000 *60 *60*24*15;
    let resta = hoy.getTime() -quincedias;
    let fechaquince = new Date(resta);
    let fechaInicio = this.datepipe.transform(fechaquince,'yyyy-MM-dd');
    this.filtrosBusqueda.fechaInicio = fechaInicio;
    this.filtrosFactura.fecha = this.initialDate();
    //this.listarProvisiones();
    
  }

  SetProveedorSelected(e:any){
    // this.objProvision.idProveedor = e.id;
    // this.objProvision.nombre = e.descripcion;
  }
  
  listarProvisiones(){
    //this.gridProvisiones.refreshData();
    
  }

  // cargar combo tupo de moneda
  LoadDataTiposMoneda() {
    // this.facturasProv.GetListadoMonedas().subscribe(
    //   (data: any) => {
    //     this.moneda = data.data;
    //     this.CargarTipoMovimientos();
    //   },
    //   (error) => {
    //     swal.fire(
    //       'Error',
    //       'Ha Ocurrio un Error al Momento de Cargar Tipos de Moneda, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
    //       error.error +
    //       '</strong>',
    //       'error'
    //     );
    //   }
    // );
  }

  // cargar combo tipo de movimientos
  CargarTipoMovimientos() {
    // this.factura.getTipoMovimientos().subscribe(
    //   (data: any) => {
    //     this.movimiento = data.data;
    //     this.CargarIvas();
    //   },
    //   (error) => {
    //     swal.fire(
    //       'Error',
    //       'Ha Ocurrio un Error al Momento de Cargar Tipo de Movimientos, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
    //       error.error +
    //       '</strong>',
    //       'error'
    //     );
    //   }
    // );
  }

  initialDate(): string {
    let date = new Date();
    let day = date.getDate().toString();
    let month = (1 + date.getMonth()).toString();
    let year = date.getFullYear().toString();

    day.length == 1 ? day = "0" + day : null;

    month.length == 1 ? month = "0" + month : null;

    return year + "-" + month + "-" + day;
  }

  pastDate(): string {
    let date = new Date();
    let fecha = date.getDate() ;
    let day = fecha.toString();
    let month = (1 + date.getMonth()).toString();
    let year = date.getFullYear().toString();

    day.length == 1 ? day = "0" + day : null;

    month.length == 1 ? month = "0" + month : null;

    return year + "-" + month + "-" + day;
  }

  CargarIvas() {
    // this.facturasProv.GetPorcentajesIva().subscribe(
    //   (data: any) => {
    //     this.iva = data.data;
    //   },
    //   (error) => {
    //     swal.fire(
    //       'Error',
    //       'Ocurrió un Error al Momento de Cargar Tipos de Moneda, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
    //       error.error +
    //       '</strong>',
    //       'error'
    //     );
    //   }
    // );
  }
  
  AbrirModalFacturas(){
    //this.openModal();
    if(this.objProvision.idProveedor == "" || this.objProvision.idProveedor == undefined){
      swal.fire('','No se ha seleccionado un proveedor','warning');
    }else{
      this.openModal(this.mdlBuscar);
      this.filtrosFactura.idProveedor = this.objProvision.idProveedor;
      let hoy = new Date();
      let quincedias = 1000 *60 *60*24*15;
      let resta = hoy.getTime() -quincedias;
      let fechaquince = new Date(resta);
      let fechaInicio = this.datepipe.transform(fechaquince,'yyyy-MM-dd');
      this.filtrosFactura.fechaInicio = fechaInicio;
      this.filtrosFactura.fechaFin = this.initialDate();
      this.listarFacturas();
    }
    
    
  }

  CerrarModalFacturas(){
    this.closeModal();
    
    this.datos = [];
    
  }

  CargarDatosFactura(e:any){
    this.objProvision.factura = e.data.factura;
    //let subtotal: number = parseFloat(e.data.subtotal).toFixed(2);
    this.objProvision.subtotal = Number(parseFloat(e.data.subtotal).toFixed(2));
    this.objProvision.idMoneda = e.data.idMoneda;
    this.objProvision.total = parseFloat(e.data.total).toFixed(2);
    this.objProvision.ivaGenerado = parseFloat(e.data.ivaGenerado).toFixed(2);
    this.objProvision.idFactura = e.data.idFactura;
    this.objProvision.ivaId = e.data.idIva;
    this.objProvision.tipoCambio = e.data.tipoCambio;
    for (const iterator of this.iva) {
      if (this.objProvision.ivaId === iterator.idIva) {
        this.objProvision.iva = iterator.valorIva;
      }
    }
    this.filtrosFactura.fecha = this.initialDate();
    this.closeModal();
    this.datos = []
  }
  abrirModalProveedor(){
    this.mdlProveedor.openModal();
  }

  onPercentChange(percent: any) {
    this.objProvision.ivaGenerado = String(Number(Number(percent) * Number(this.objProvision.iva/100)).toFixed(2));
    //this.objProvision.subtotal = parseFloat((this.objProvision.subtotal) +(this.objProvision.ivaGenerado)).toFixed(2);
    this.objProvision.total = String(Number(Number(this.objProvision.subtotal) +Number(this.objProvision.ivaGenerado)).toFixed(2));
  }

  cambia(e:any){
    for (const iterator of this.iva) {
      if (this.objProvision.ivaId === iterator.idIva) {
        this.objProvision.iva = iterator.valorIva;
      }
    }

    this.objProvision.ivaGenerado = String(Number(Number(this.objProvision.subtotal) * Number(this.objProvision.iva/100)).toFixed(2));
    
    if(this.objProvision.subtotal != 0){

    }else{
      //let subtotal: string = parseFloat((this.objProvision.subtotal) +(this.objProvision.ivaGenerado)).toFixed(2);
      this.objProvision.subtotal = Number(parseFloat((this.objProvision.subtotal) +(this.objProvision.ivaGenerado)).toFixed(2));
    }
    
    this.objProvision.total = String(Number(Number(this.objProvision.subtotal) +Number(this.objProvision.ivaGenerado)).toFixed(2));
  }

  
  listarFacturas() {
    this.filtrosFactura["endRow"] = 10;
    this.filtrosFactura["startRow"] = 0;
    this.factura.listarFacturas(this.filtrosFactura).subscribe(
      (data: any) => {
        if(data.totalRecords != 0){
        this.datos = data.data;
        this.activaCampos = true;
        this.CargarIvas();
        }else{
          this.activaCampos = false;
        }
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar las facturas, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }

  guardarProvision(){
  if(this.objProvision.idProveedor == "" || this.objProvision.idFactura == "" || this.objProvision.subtotal == 0 || this.objProvision.ivaGenerado == "" || this.objProvision.total == ""){
    swal.fire('', 'Hay datos de la provisión que no se han capturado','warning')
  }else{
  this.objProvision.fecha = this.filtrosFactura.fecha;
  this.factura.guardarProvision(this.objProvision).subscribe((data: any) => {
  if (data.data.errorMessage == null) {
    swal.fire(
      '',
      'Provisión guardada correctamente',
      'success'
    );
    this.objProvision = {
      idProveedor:"",
      nombre:"",
      fecha:"",
      idMoneda:0,
      subtotal: 0.00 ,
      ivaGenerado: "",
      total:"",
      tipoCambio:0.00,
      ivaId:0,
      iva:0,
      idFactura:"",
      documento:"",
      idTipoMovto:0,
      factura:"",
      idProvision:0
    }
    //this.closeModal();
    this.modalService.dismissAll();
    this.gridProvisiones.refreshData();
  } else {
    swal.fire(
      '',
      'Ocurrió un error al tratar de guardar los datos ' +
        data.data.errorMessage,
      'error'
    );
  }
},
(error) => {
  swal.fire(
    'Datos ',
    ' Ocurrió un Error al Momento de Guardar una Provisión Factura,' +
      ' Favor de Comunicarse con el Área de Informática y Generar un Reporte de Fallas,' +
      ' <strong>Código de Error: ' +
      error.error +
      '</strong>',
    'error'
  );
}
);
  }
}

//ABRIR MODAL
openModal(content){
  this.modalRef = this.modalService.open(content, {
    size: 'lg',
    backdrop: 'static',
    keyboard: false
  });
  this.modalRef.result.then(() => {
    
  });
}

//CERRAR MODAL
closeModal(): void {
  this.modalRef.close();
}

GridEliminar(e): void {
  swal
    .fire({
      title: '¿Está seguro de eliminar la Provisión?',
      text: '',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar',
      cancelButtonText: 'Cancelar',
    })
    .then((result) => {
      if (result.isConfirmed) {
        
        this.factura.eliminarProvision(String(e.data.idProvision)).subscribe(
          (data: any) => {
            if (data.data.errorMessage != "") {
              swal.fire(
                '',
                'Los cambios en el registro fueron exitosos',
                'success'
              );
              this.gridProvisiones.refreshData();
            } else {
              swal.fire(
                '',
                'Ocurrió un error al tratar de hacer los cambios. ' +
                  data.mensaje,
                'error'
              );
            }
          },
          (error) => {
            swal.fire(
              'Datos ',
              'Ha Ocurrio un Error al Momento de Eliminar o Activar la Provisión,' +
                ' Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas,' +
                ' <strong>Código de Error: ' +
                error.error +
                '</strong>',
              'error'
            );
          }
        );
      }
      this.gridProvisiones.refreshData();
    });
}

editar(e:any){
  this.objProvision.idProvision = e.data.idProvision;
  this.objProvision.idProveedor = e.data.idProveedor;
  this.objProvision.nombre = e.data.descripcion;
  this.objProvision.factura = e.data.factura;
  this.objProvision.idTipoMovto = e.data.idTipoMovto;
  this.objProvision.idMoneda = e.data.idMoneda;
  this.objProvision.idFactura = e.data.idFactura;
  this.objProvision.tipoCambio = e.data.tipoCambio;
  this.objProvision.ivaId = e.data.ivaId;
  this.objProvision.subtotal = e.data.subtotal;
  this.objProvision.ivaGenerado = e.data.ivaGenerado;
  this.objProvision.total = e.data.total;
  this.objProvision.documento = e.data.documento;
  this.openModalRef(this.mdlProvision);
}

abrirModalProvision(){
  this.objProvision = {
    idProveedor:"",
    nombre:"",
    fecha:"",
    idMoneda:0,
    subtotal: 0.00 ,
    ivaGenerado: "",
    total:"",
    tipoCambio:0.00,
    ivaId:0,
    iva:0,
    idFactura:"",
    documento:"",
    idTipoMovto:0,
    factura:"",
    idProvision:0
  }
  this.openModalRef(this.mdlProvision);
}

cerrar(){
  //this.modalService.dismissAll();
  this.modalReference.close();
}

openModalRef(content){
  this.modalReference = this.modalService.open(content, {
    size: 'lg',
    backdrop: 'static',
    keyboard: false
  });
  this.modalReference.result.then(() => {
    
  });
}

  
}
