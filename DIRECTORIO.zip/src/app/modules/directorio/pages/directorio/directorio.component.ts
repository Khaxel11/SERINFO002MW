import { Component, OnInit, ViewChild } from '@angular/core';
import { DirectorioService } from '../../../../services/directorio.service';
import swal from 'sweetalert2';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-directorio',
  templateUrl: './directorio.component.html',
  styleUrls: ['./directorio.component.css']
})
export class DirectorioComponent implements OnInit {
  @ViewChild('gridDir') public gridDir: any;
  @ViewChild('gridGuia') public gridGuia: any;
  public filtroDirectorio = {
    nousuario:0,
    nombre: "",
    departamento: "",
    lugar: "",
    extencion: ""
  }
  public filtrosMarcado = {
    ubicacion : "6"
  }
  public filtrosBusqueda = {
    nousuario: "",
    nombre: "",
    departamento: "",
    lugar: "",
    extension: ""
  }
  public marcado = {
    destino: "",
    clave: ""
  }

  
  columnDefs: any;
  columnDir: any;
usuarios = []
guiaSelect = []
lista = []
idLugar : number = null
public Ubicacionzona:string = "Culiacán";
  constructor(public dire: DirectorioService) {
    this.columnDefs = [
      {
        headerName: 'Destino',
        field: 'destino',
        maxWidth : 150,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Clave',
        field: 'clave',
        maxWidth : 150,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
      }
    ];
    
    this.columnDir = [
      {
        headerName: 'Clave',
        field: 'clave',
        flex: 5,
        minWidth: 50,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Nombre',
        field: 'nombre',
        flex: 14,
        minWidth: 140,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      }
      ,
      {
        headerName: 'Extension',
        field: 'extension',
        flex: 6,
        minWidth: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Movil',
        field: 'movil',
        flex: 7,
        minWidh: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Casa',
        field: 'casa',
        flex: 7,
        minWidh: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Oficina',
        field: 'oficina',
        flex: 7,
        minWidh: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Personalizado',
        field: 'personalizado',
        flex: 8,
        minWidh: 80,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Correo',
        field: 'correo',
        flex: 10,
        minWidth: 100,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Departamento',
        field: 'departamento',
        flex: 10,
        minWidth: 100,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Lugar',
        field: 'lugar',
        flex: 8,
        minWidth: 80,
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-center',
      }

    ]
   }

  ngOnInit(): void {
    this.listarUsuarios();
    this.listarUbicacion();
    this.listar();
    
  }
  listarUsuarios() {
    this.dire.getUsuarios(this.filtrosBusqueda).subscribe(
      (data: any) => {
        if(data.data.length > 0){

        this.usuarios = data.data;
          
        }else{
          this.usuarios = [];
        }
        
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar el Directorio, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
   
  }
  listar() {
    this.dire.getUbicacion().subscribe(
      (data: any) => {
        if(data.data.length > 0){

        this.lista = data.data;
  
        }else{
          this.lista = [];
        }
        
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar el Directorio, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
    );
  }
  limpiar(){
    this.filtrosBusqueda.nousuario = "";
    this.filtrosBusqueda.nombre = "";
    this.filtrosBusqueda.departamento = "";
    this.filtrosBusqueda.extension = "";
    this.filtrosBusqueda.lugar = "0";
    this.filtrosBusqueda.lugar = "0";
    this.listarUsuarios();
  }

  listarUbicacion() {
    
    this.dire.getMarcado(this.filtrosMarcado.ubicacion).subscribe(
      (data: any) => {
        if(data.data.length > 0){
          this.guiaSelect = data.data;

        }else{
          this.guiaSelect = [];
        }
        
      },
      (error) => {
        swal.fire(
          'Error',
          'Ocurrió un Error al Momento de Cargar la Guía de Marcado, Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas, <strong>Código de Error: ' +
          error.error +
          '</strong>',
          'error'
        );
      }
      
    );
  }

  onKey(e){ 
    this.filtrosBusqueda.nousuario;
    this.filtrosBusqueda.nombre;
    this.filtrosBusqueda.departamento;
    this.filtrosBusqueda.extension;
    this.listarUsuarios();
  }
  onOptionSelected(e){
    this.listarUsuarios();
    this.getIndexes();
  }
  getIndexes(){
    
    switch(this.filtrosBusqueda.lugar){
      case this.filtrosBusqueda.lugar = "Planta Navojoa":
        this.idLugar = 2;  
      break;
      case this.filtrosBusqueda.lugar = "Nave Oriente":
        this.idLugar = 3;  
      break;
      case this.filtrosBusqueda.lugar = "Oficinas Navojoa":
        this.idLugar = 4;  
      break;
      case this.filtrosBusqueda.lugar = "Culiacán":
        this.idLugar = 6;  
      break;
      case this.filtrosBusqueda.lugar = "Planta Hermosillo":
        this.idLugar = 7;  
      break;
      case this.filtrosBusqueda.lugar = "Planta Tijuana":
        this.idLugar = 8;  
      break;
        
      default:
        this.filtrosBusqueda.lugar = "0";
        this.idLugar = null;
      break;
    }
    
  }
  abrirReportes(){
    
    if(this.idLugar == null){
      window.open("http://datosnv2008.cecso.com.mx/ReportServer/Pages/ReportViewer.aspx?%2fInformatica%2fMNUSRS001%2fMnuSRS001" +"&Clave=" +this.filtrosBusqueda.nousuario+"&NombreUsuario="+this.filtrosBusqueda.nombre+"&Departamento="+this.filtrosBusqueda.departamento+"&EXT="+this.filtrosBusqueda.extension+"&Lugar="
      ,"_blank");
      
    }else{
      window.open("http://datosnv2008.cecso.com.mx/ReportServer/Pages/ReportViewer.aspx?%2fInformatica%2fMNUSRS001%2fMnuSRS001" +"&Clave=" +this.filtrosBusqueda.nousuario+"&NombreUsuario="+this.filtrosBusqueda.nombre+"&Departamento="+this.filtrosBusqueda.departamento+"&EXT="+this.filtrosBusqueda.extension+"&Lugar="+this.idLugar
    ,"_blank"); 
    this.idLugar = null; 
    
    }
    
    
  }
 
}
