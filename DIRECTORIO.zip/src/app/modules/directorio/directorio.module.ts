import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DirectorioRoutingModule } from './directorio-routing.module';
import { DirectorioComponent } from './pages/directorio/directorio.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [DirectorioComponent],
  imports: [
    CommonModule,
    DirectorioRoutingModule,
    SharedModule
  ]
})
export class DirectorioModule { }
