import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule} from '../../shared/shared.module';
import { ADMCXPA001MWRoutingModule } from './admcxpa001-mw-routing.module';
import { ADMCXPA001mwComponent } from './pages/admcxpa001mw/admcxpa001mw.component';


@NgModule({
  declarations: [ADMCXPA001mwComponent],
  imports: [
    CommonModule,
    ADMCXPA001MWRoutingModule,
    SharedModule
  ]
})
export class ADMCXPA001MWModule { }
