import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/helpers/auth.guard';
import { ADMCXPA001mwComponent} from './pages/admcxpa001mw/admcxpa001mw.component'

const routes: Routes = [
  { path: 'admcxpa001mw', component: ADMCXPA001mwComponent, canActivate: [AuthGuard]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ADMCXPA001MWRoutingModule { }
