import { Component, OnInit, ViewChild } from '@angular/core';
import { TipoMovimientoService} from '../../../../services/tipo-movimiento.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-admcxpa001mw',
  templateUrl: './admcxpa001mw.component.html',
  styleUrls: ['./admcxpa001mw.component.css'],
  providers: [TipoMovimientoService]
})

export class ADMCXPA001mwComponent implements OnInit {
  @ViewChild('gridEjecutivo') private Grid: any;
  @ViewChild('mdlAgregar') private modal: any;
  @ViewChild('mdlEditar') private modalEditar: any;
  public filtrosBusqueda = {
    filtro:"",
    startRow:0,
    endRow:0
  };
  columnDefs: any;
  accion:any;
  titulo:any;
  objTipo ={
    descripcion: "",
    cargoAbono:"",
    generaCheque:false,
    idMaterial:"",
    tipoMovimientoFlete:false,
    id:0,
    usuario:""
  };
  objEditar = {
    descripcion: "",
    cargoAbono:"",
    generaCheque:false,
    idMaterial:"",
    tipoMovimientoFlete:false,
    id:0,
    usuario:""
  };

  activarMaterial:any;
  constructor(public tipoMov:TipoMovimientoService) { 
    this.columnDefs = [
      {
        headerName: 'Id',
        field: 'id',
        flex: 2,
        minWidth: 80,
        headerClass: 'header-center header-grid-left',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Nombre',
        field: 'descripcion',
        flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'T/Mov.',
        field: 'cargoAbono'
        ,flex: 10,
        minWidth: 50,
        headerClass: 'header-center header-grid',
        cellClass: 'grid-cell-center',
      },
      {
        headerName: 'Editar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.editar.bind(this),
          label: '<i class="fa fa-edit"></i>',
          class: 'btn btn-warning btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
      {
        headerName: 'Eliminar',
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          onClick: this.GridEliminar.bind(this),
          label: 
            '<i class="fa fa-trash"></i>',
          class: 'btn btn-danger btn-sm',
        },
        headerClass: 'header-center header-grid-right',
        cellClass: 'grid-cell-btn-center',
        flex: 5,
        minWidth: 90,
        maxWidth: 90,
        suppressSizeToFit: true,
      },
    ];

  }

  ngOnInit(): void {
  }

  goToEditView(){
    this.modalEditar.openModal();
  }
  goToAddView(){

  }

  listarTipoMovimientos(){
    this.Grid.refreshData();
  }

  AbrirModal(): void {
    // this.modal.openModal();
    // this.objTipo ={
    //   descripcion: "",
    //   cargoAbono:"",
    //   generaCheque:false,
    //   idMaterial:"",
    //   tipoMovimientoFlete:false,
    //   id:0,
    //   usuario:""
    // };
    // if(this.objTipo.tipoMovimientoFlete == true){
    //   this.activarMaterial = true;
    // }else{
    //   this.activarMaterial = false;
    // }
  }
  
  
  CerrarModal(): void {
    //this.modal.closeModal();
    
  }
  CerrarModalEditar(){
    //this.modalEditar.closeModal();
  }


  editar(e){
    // this.modalEditar.openModal();
    // this.objEditar.id = e.data.id;
    // this.objEditar.descripcion = e.data.descripcion;
    // this.objEditar.cargoAbono = e.data.cargoAbono;
    // this.objEditar.generaCheque = e.data.generaCheque;
    // this.objEditar.idMaterial = e.data.idMaterial;
    // this.objEditar.tipoMovimientoFlete = e.data.tipoMovimientoFlete;
    // if(this.objEditar.tipoMovimientoFlete == true){
    //    this.activarMaterial = true;
    // }
  }

  GridEliminar(e): void {
    // swal
    //   .fire({
    //     title: '¿Está seguro de eliminar el Tipo de movimiento?',
    //     text: '',
    //     icon: 'warning',
    //     showCancelButton: true,
    //     confirmButtonColor: '#3085d6',
    //     cancelButtonColor: '#d33',
    //     confirmButtonText: 'Aceptar',
    //     cancelButtonText: 'Cancelar',
    //   })
    //   .then((result) => {
    //     console.log(e.data.id);
    //     if (result.isConfirmed) {
          

    //       this.tipoMov.eliminarTipoMovimiento(String(e.data.id)).subscribe(
    //         (data: any) => {
    //           if (data.correcto) {
    //             swal.fire(
    //               '',
    //               'Los cambios en el registro fueron exitosos',
    //               'success'
    //             );
    //             this.Grid.refreshData();
    //           } else {
    //             swal.fire(
    //               '',
    //               'Ocurrió un error al tratar de hacer los cambios. ' +
    //                 data.mensaje,
    //               'error'
    //             );
    //           }
    //         },
    //         (error) => {
    //           swal.fire(
    //             'Datos ',
    //             'Ha Ocurrio un Error al Momento de Eliminar o Activar el Articulo,' +
    //               ' Favor de Comunicarse con el Área de Informatica y Generar un Reporte de Fallas,' +
    //               ' <strong>Código de Error: ' +
    //               error.error +
    //               '</strong>',
    //             'error'
    //           );
    //         }
    //       );
    //     }
    //     this.Grid.refreshData();
    //   });
  }

  guardarTipoMov(){
  //   if(this.objTipo.descripcion == null || this.objTipo.descripcion == undefined || this.objTipo.cargoAbono == undefined || this.objTipo.cargoAbono == ""){
  //     swal.fire('¡Hecho!', 'Hay campos vacios', 'warning');
  //   }else{
  //   this.objTipo.usuario = localStorage.getItem('IdUsuario');
  //   this.tipoMov.guardarTipoMovimiento(this.objTipo).subscribe(success => {
  //     swal.fire('¡Hecho!', 'Registro guardado correctamente', 'success');
  //     this.objTipo ={
  //       descripcion: "",
  //       cargoAbono:"",
  //       generaCheque:false,
  //       idMaterial:"",
  //       tipoMovimientoFlete:false,
  //       id:0,
  //       usuario:""
  //     };
  //     this.Grid.refreshData();
      
  //   }, Error => {
  //     swal.fire('Error!', 'Error al llamar servicios ' + Error.message, 'error');
  //   });
  // }
   }

  editarTipoMov(){
  //   if(this.objEditar.descripcion == null || this.objEditar.descripcion == undefined || this.objEditar.cargoAbono == undefined || this.objEditar.cargoAbono == "")
  //     swal.fire('¡Hecho!', 'Hay campos vacios', 'warning');
  //   else
    
  //   this.tipoMov.editarTipoMovimiento(this.objEditar).subscribe(success => {
  //     swal.fire('¡Hecho!', 'Registro editado correctamente', 'success');
  //     this.Grid.refreshData();
  //     this.modalEditar.closeModal();
  //   }, Error => {
  //     swal.fire('Error!', 'Error al llamar servicios ' + Error.message, 'error');
  //   });
  }

  material(evento:any){
    if(evento.target.checked){
      this.activarMaterial = true;
    }else{
      this.activarMaterial = false;
    }
  }

}
