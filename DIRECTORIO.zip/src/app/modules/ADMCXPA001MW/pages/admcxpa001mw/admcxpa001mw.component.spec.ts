import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ADMCXPA001mwComponent } from './admcxpa001mw.component';

describe('ADMCXPA001mwComponent', () => {
  let component: ADMCXPA001mwComponent;
  let fixture: ComponentFixture<ADMCXPA001mwComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ADMCXPA001mwComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ADMCXPA001mwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
