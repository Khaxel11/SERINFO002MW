import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-articulo',
  templateUrl: './modal-articulo.component.html',
  styleUrls: ['./modal-articulo.component.scss']
})
export class ModalArticuloComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
